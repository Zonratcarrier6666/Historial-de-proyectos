/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model_controller;

/**
 *
 * @author angel
 */
public class Cola {
    private int[] cola;
    private int primero; // Índice del frente de la cola
    private int ultimo;  // Índice del final de la cola
    private int size;  // Tamaño actual de la cola

    public Cola(int capacidad) {
        cola = new int[capacidad];
        primero = 0;
        ultimo = -1;
        size = 0;
    }

    // Método para añadprimeroir un elemento al final de la cola
    public void enqueue(int elemento) {
        if (size < cola.length) {
            ultimo = (ultimo + 1) % cola.length;
            cola[ultimo] = elemento;
            size++;
        } else {
            System.out.println("La cola está llena. No se puede agregar más elementos.");
        }
    }

    // Método para extraer y eliminar el último elemento de la cola
    public int dequeue() {
        if (isEmpty()) {
            throw new IllegalStateException("La cola está vacía");
        }
        int elemento = cola[primero];
        primero = (primero + 1) % cola.length;
        size--;
        return elemento;
    }

    // Método para verificar si la cola está vacía
    public boolean isEmpty() {
        return size == 0;
    }

    // Método para ver el último elemento de la cola sin eliminarlo
    public int peek() {
        if (isEmpty()) {
            throw new IllegalStateException("La cola está vacía");
        }
        return cola[primero];
    }

    // Método para obtener el tamaño de la cola
    public int size() {
        return size;
    } 
}
