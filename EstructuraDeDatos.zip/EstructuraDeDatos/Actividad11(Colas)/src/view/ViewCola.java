/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package view;

import java.util.Scanner;
import model_controller.Cola;

/**
 *
 * @author angel
 */
public class ViewCola {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int capacity;

        System.out.print("Ingrese la capacidad de la cola: ");
        capacity = scanner.nextInt();

        Cola cola = new Cola(capacity); // Crear una cola con la capacidad especificada

        while (true) {
            System.out.println("\nOperaciones de la cola:");
            System.out.println("1. Enqueue (Añadir elemento)");
            System.out.println("2. Dequeue (Extraer elemento)");
            System.out.println("3. Peek (Ver último elemento)");
            System.out.println("4. Tamaño de la cola");
            System.out.println("5. Salir");
            System.out.print("Elija una operación (1-5): ");

            int opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el elemento a añadir: ");
                    int elemento = scanner.nextInt();
                    cola.enqueue(elemento);
                    break;
                case 2:
                    try {
                    int elementoExtraido = cola.dequeue();
                    System.out.println("Elemento extraído: " + elementoExtraido);
                } catch (IllegalStateException e) {
                    System.out.println("La cola está vacía. No se puede extraer.");
                }
                break;
                case 3:
                    try {
                    int elementoUltimo = cola.peek();
                    System.out.println("Último elemento: " + elementoUltimo);
                } catch (IllegalStateException e) {
                    System.out.println("La cola está vacía. No hay elementos en la cola.");
                }
                break;
                case 4:
                    System.out.println("Tamaño de la cola: " + cola.size());
                    break;
                case 5:
                    System.out.println("Saliendo del programa.");
                    System.exit(0);
                default:
                    System.out.println("Opción no válida. Por favor, elija una opción válida.");
            }
        }
    }

}
