
package View;

import controller.ArbolBinario;
import java.util.Scanner;

/**
 *
 * @author angel
 */
public class view {
    public static void main(String[] args) {
     
        ArbolBinario arbol = new ArbolBinario();
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;

        while (!salir) {
            System.out.println("\n-------- Menú --------");
            System.out.println("1. Cargar palabras desde archivo CSV");
            System.out.println("2. Mostrar árbol en inorden");
            System.out.println("3. Eliminar palabra");
            System.out.println("4. Eliminar subárbol izquierdo");
            System.out.println("5. Mostrar recorrido en inorden");
            System.out.println("6. Mostrar recorrido en preorden");
            System.out.println("7. Mostrar recorrido en posorden");
            System.out.println("8. Verificar existencia de palabra");
            System.out.println("9. Salir");

            System.out.print("Seleccione una opción: ");
            int opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    scanner.nextLine(); // Consumir el salto de línea pendiente
                    System.out.print("Ingrese el nombre del archivo CSV: ");
                    String nombreArchivo = scanner.nextLine();
                    arbol.cargarDesdeArchivo(nombreArchivo);
                    break;
                case 2:
                    System.out.println("\nÁrbol en inorden:");
                    arbol.inordenTraversal();
                    break;
                case 3:
                    scanner.nextLine(); // Consumir el salto de línea pendiente
                    System.out.print("Ingrese la palabra a eliminar: ");
                    String palabraAEliminar = scanner.nextLine();
                    arbol.eliminarNodo(palabraAEliminar);
                    break;
                case 4:
                    scanner.nextLine(); // Consumir el salto de línea pendiente
                    System.out.print("Ingrese la palabra del nodo padre para eliminar su subárbol izquierdo: ");
                    String palabraPadreAEliminar = scanner.nextLine();
                    arbol.eliminarSubarbolIzquierdo(palabraPadreAEliminar);
                    break;
                case 5:
                    System.out.println("\nRecorrido en inorden:");
                    arbol.inordenTraversal();
                    break;
                case 6:
                    System.out.println("\nRecorrido en preorden:");
                    arbol.preordenTraversal();
                    break;
                case 7:
                    System.out.println("\nRecorrido en posorden:");
                    arbol.posordenTraversal();
                    break;
                case 8:
                    scanner.nextLine(); // Consumir el salto de línea pendiente
                    System.out.print("Ingrese una palabra para verificar su existencia en el árbol: ");
                    String palabraAVerificar = scanner.nextLine();
                    if (arbol.existePalabra(palabraAVerificar)) {
                        System.out.println("La palabra existe en el árbol.");
                    } else {
                        System.out.println("La palabra no existe en el árbol.");
                    }
                    break;
                case 9:
                    salir = true;
                    break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
                    break;
            }
        }

        // Cerrar el scanner al finalizar
        scanner.close();
    }
    
}
