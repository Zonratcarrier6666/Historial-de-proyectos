
package controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import model.Nodo;

/**
 *
 * @author angel
 */
public class ArbolBinario {
    private Nodo raiz;

    public ArbolBinario() {
        this.raiz = null;
    }

    public void cargarDesdeArchivo(String archivoCSV) {
       try (BufferedReader br = new BufferedReader(new FileReader(archivoCSV))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                // Separar la línea en concepto y definicion (asumiendo que están separados por coma)
                String[] partes = linea.split(",");
                String concepto = partes[0].trim(); // Obtener el concepto de la primera columna
                insertarNodo(concepto);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void insertarNodo(String palabra) {
        raiz = insertar(raiz, palabra);
    }

    private Nodo insertar(Nodo nodo, String palabra) {
        if (nodo == null) {
            return new Nodo(palabra);
        }

        int comparacion = palabra.compareTo(nodo.getPalabra());
        if (comparacion < 0) {
            nodo.setIzquierdo(insertar(nodo.getIzquierdo(), palabra));
        } else if (comparacion > 0) {
            nodo.setDerecho(insertar(nodo.getDerecho(), palabra));
        }

        return nodo;
    }

    public void eliminarNodo(String palabra) {
        raiz = eliminar(raiz, palabra);
    }

    private Nodo eliminar(Nodo nodo, String palabra) {
        if (nodo == null) {
            return null;
        }

        int comparacion = palabra.compareTo(nodo.getPalabra());
        if (comparacion < 0) {
            nodo.setIzquierdo(eliminar(nodo.getIzquierdo(), palabra));
        } else if (comparacion > 0) {
            nodo.setDerecho(eliminar(nodo.getDerecho(), palabra));
        } else {
            if (nodo.getIzquierdo() == null) {
                return nodo.getDerecho();
            } else if (nodo.getDerecho() == null) {
                return nodo.getIzquierdo();
            }

            nodo.setPalabra(encontrarSucesor(nodo.getDerecho()));
            nodo.setDerecho(eliminar(nodo.getDerecho(), nodo.getPalabra()));
        }

        return nodo;
    }

    private String encontrarSucesor(Nodo nodo) {
        while (nodo.getIzquierdo() != null) {
            nodo = nodo.getIzquierdo();
        }
        return nodo.getPalabra();
    }

    public void eliminarSubarbolIzquierdo(String palabraPadre) {
        raiz = eliminarSubarbolIzquierdo(raiz, palabraPadre);
    }

    private Nodo eliminarSubarbolIzquierdo(Nodo nodo, String palabraPadre) {
        if (nodo == null) {
            return null;
        }

        int comparacion = palabraPadre.compareTo(nodo.getPalabra());
        if (comparacion < 0) {
            nodo.setIzquierdo(eliminarSubarbolIzquierdo(nodo.getIzquierdo(), palabraPadre));
        } else if (comparacion > 0) {
            // No hace nada en el subárbol izquierdo si el valor del padre es mayor
        } else {
            nodo.setIzquierdo(null);
        }

        return nodo;
    }

    public void inordenTraversal() {
        inorden(raiz);
    }

    private void inorden(Nodo nodo) {
        if (nodo != null) {
            inorden(nodo.getIzquierdo());
            System.out.print(nodo.getPalabra() + " ");
            inorden(nodo.getDerecho());
        }
    }

    public void preordenTraversal() {
        preorden(raiz);
    }

    private void preorden(Nodo nodo) {
        if (nodo != null) {
            System.out.print(nodo.getPalabra() + " ");
            preorden(nodo.getIzquierdo());
            preorden(nodo.getDerecho());
        }
    }

    public void posordenTraversal() {
        posorden(raiz);
    }

    private void posorden(Nodo nodo) {
        if (nodo != null) {
            posorden(nodo.getIzquierdo());
            posorden(nodo.getDerecho());
            System.out.print(nodo.getPalabra() + " ");
        }
    }

    public boolean existePalabra(String palabra) {
        return existe(raiz, palabra);
    }

    private boolean existe(Nodo nodo, String palabra) {
        if (nodo == null) {
            return false;
        }

        int comparacion = palabra.compareTo(nodo.getPalabra());
        if (comparacion < 0) {
            return existe(nodo.getIzquierdo(), palabra);
        } else if (comparacion > 0) {
            return existe(nodo.getDerecho(), palabra);
        } else {
            return true;
        }
    }
}
