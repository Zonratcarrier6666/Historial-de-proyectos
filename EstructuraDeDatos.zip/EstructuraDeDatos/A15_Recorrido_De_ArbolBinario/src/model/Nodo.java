
package model;

/**
 *
 * @author angel
 */
public class Nodo {
    private String palabra;
    private Nodo izquierdo;
    private Nodo derecho;
     // Constructor
    public Nodo(String palabra) {
        this.palabra = palabra;
        this.izquierdo = null;
        this.derecho = null;
    }

    // Métodos getter y setter para la palabra
    public String getPalabra() {
        return palabra;
    }

    public void setPalabra(String palabra) {
        this.palabra = palabra;
    }

    // Métodos getter y setter para el nodo izquierdo
    public Nodo getIzquierdo() {
        return izquierdo;
    }

    public void setIzquierdo(Nodo izquierdo) {
        this.izquierdo = izquierdo;
    }

    // Métodos getter y setter para el nodo derecho
    public Nodo getDerecho() {
        return derecho;
    }

    public void setDerecho(Nodo derecho) {
        this.derecho = derecho;
    }
}
