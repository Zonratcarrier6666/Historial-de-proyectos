
package model;

/**
 *
 * @author angel
 */
public class Nodo {
     private int valor;
    private Nodo izquierdo;
    private Nodo derecho;

    // Constructor
    public Nodo(int valor) {
        this.valor = valor;
        this.izquierdo = null;
        this.derecho = null;
    }

    // Métodos getter y setter para el valor
    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    // Métodos getter y setter para el nodo izquierdo
    public Nodo getIzquierdo() {
        return izquierdo;
    }

    public void setIzquierdo(Nodo izquierdo) {
        this.izquierdo = izquierdo;
    }

    // Métodos getter y setter para el nodo derecho
    public Nodo getDerecho() {
        return derecho;
    }

    public void setDerecho(Nodo derecho) {
        this.derecho = derecho;
    }
}
