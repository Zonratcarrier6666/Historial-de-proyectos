package controller;

import model.Nodo;

/**
 *
 * @author angel
 */
public class ArbolBinario {

    private Nodo raiz;

    public ArbolBinario() {
        this.raiz = null;
    }

    public void insertarNodo(int valor) {
        raiz = insertar(raiz, valor);
    }

    private Nodo insertar(Nodo nodo, int valor) {
        if (nodo == null) {
            return new Nodo(valor);
        }

        if (valor < nodo.getValor()) {
            nodo.setIzquierdo(insertar(nodo.getIzquierdo(), valor));
        } else if (valor > nodo.getValor()) {
            nodo.setDerecho(insertar(nodo.getDerecho(), valor));
        }

        return nodo;
    }

    public void eliminarNodo(int valor) {
        raiz = eliminar(raiz, valor);
    }

private Nodo eliminar(Nodo nodo, int valor) {
    if (nodo == null) {
        return null;
    }

    if (valor < nodo.getValor()) {
        nodo.setIzquierdo(eliminar(nodo.getIzquierdo(), valor));
    } else if (valor > nodo.getValor()) {
        nodo.setDerecho(eliminar(nodo.getDerecho(), valor));
    } else {
        if (nodo.getIzquierdo() == null) {
            return nodo.getDerecho();
        } else if (nodo.getDerecho() == null) {
            return nodo.getIzquierdo();
        }

        // Encuentra el sucesor en lugar de simplemente tomar el nodo más izquierdo del subárbol derecho
        nodo.setValor(encontrarSucesor(nodo.getDerecho()));
        // Elimina el sucesor encontrado
        nodo.setDerecho(eliminar(nodo.getDerecho(), nodo.getValor()));
    }

    return nodo;
}

     public void eliminarSubarbolIzquierdo(int valorPadre) {
        raiz = eliminarSubarbolIzquierdo(raiz, valorPadre);
    }

    private Nodo eliminarSubarbolIzquierdo(Nodo nodo, int valorPadre) {
        if (nodo == null) {
            return null;
        }

        
        if (valorPadre < nodo.getValor()) {
            // Si el valor del padre es menor, recursivamente eliminar el subárbol izquierdo
            nodo.setIzquierdo(eliminarSubarbolIzquierdo(nodo.getIzquierdo(), valorPadre));
        } else if (valorPadre > nodo.getValor()) {
            // Si el valor del padre es mayor, no hagas nada en el subárbol izquierdo
            // porque estamos eliminando el subárbol izquierdo de este nodo
        } else {
            // Encontramos el nodo padre, eliminamos su subárbol izquierdo
            nodo.setIzquierdo(null);
        }
        return nodo;
    }
private int encontrarSucesor(Nodo nodo) {
    while (nodo.getIzquierdo() != null) {
        nodo = nodo.getIzquierdo();
    }
    return nodo.getValor();
}

    // Método para realizar un recorrido inorden del árbol
    public void inordenTraversal() {
        inorden(raiz);
    }

    // Método auxiliar para realizar un recorrido inorden recursivo
    private void inorden(Nodo nodo) {
        if (nodo != null) {
            inorden(nodo.getIzquierdo());
            System.out.print(nodo.getValor() + " ");
            inorden(nodo.getDerecho());
        }
    }

    // Método para imprimir el árbol visualmente
    public void imprimirArbol() {
        imprimirArbol(raiz, 0);
    }

    // Método auxiliar para imprimir el árbol recursivamente
    private void imprimirArbol(Nodo nodo, int nivel) {
        if (nodo != null) {
            imprimirArbol(nodo.getDerecho(), nivel + 1);
            for (int i = 0; i < nivel * 4; i++) {
                System.out.print(" ");  // Aumenta el espacio según el nivel del nodo
            }
            System.out.println(nodo.getValor());
            imprimirArbol(nodo.getIzquierdo(), nivel + 1);
        }
    }
}
