package View;

import controller.ArbolBinario;
import java.util.Scanner;

/**
 *
 * @author angel
 */
public class view {
 public static void main(String[] args) {
        ArbolBinario arbol = new ArbolBinario();
        Scanner scanner = new Scanner(System.in);

        // Solicitar al usuario que ingrese nodos al árbol
        System.out.print("Ingrese el valor del nodo (o -1 para finalizar): ");
        int valorNodo = scanner.nextInt();
        while (valorNodo != -1) {
            arbol.insertarNodo(valorNodo);
            System.out.print("Ingrese el valor del nodo (o -1 para finalizar): ");
            valorNodo = scanner.nextInt();
        }

        // Mostrar el árbol antes de la eliminación
        System.out.println("Árbol antes de la eliminación:");
        arbol.imprimirArbol();
        System.out.println();



        // Mostrar el árbol después de la eliminación
        System.out.println("\nÁrbol después de la eliminación:");
        arbol.imprimirArbol();

        // Solicitar al usuario que ingrese el valor del nodo padre para eliminar su subárbol izquierdo
        System.out.print("\nIngrese el valor del nodo padre para eliminar su subárbol izquierdo: ");
        int valorPadreAEliminar = scanner.nextInt();
        arbol.eliminarSubarbolIzquierdo(valorPadreAEliminar);

        // Mostrar el árbol después de eliminar el subárbol izquierdo
        System.out.println("\nÁrbol después de eliminar el subárbol izquierdo:");
        arbol.imprimirArbol();

        // Cerrar el scanner al finalizar
        scanner.close();
    }
}