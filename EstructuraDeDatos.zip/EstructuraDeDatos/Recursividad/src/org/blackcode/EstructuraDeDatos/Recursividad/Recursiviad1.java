/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.blackcode.EstructuraDeDatos.Recursividad;

public class Recursiviad1 {

    public static void dibujarRectangulo(int filas, int columnas, int contadorFilas) {
        if (contadorFilas == filas) {
            return;
        }

        dibujarFila(columnas, 0, contadorFilas);
        System.out.println();

        dibujarRectangulo(filas, columnas, contadorFilas + 1);
    }

    public static void dibujarFila(int columnas, int contadorColumnas, int contadorFilas) {
        if (contadorColumnas == columnas) {
            return;
        }

        if (contadorFilas == 0 || contadorFilas == (columnas - 1) || contadorColumnas == 0 || contadorColumnas == (columnas - 1)) {
            System.out.print("[ ]");
        } else {
            System.out.print("[ ]");
        }

        dibujarFila(columnas, contadorColumnas + 1, contadorFilas);
    }
    
    public static void dibujarRectangulo2(int filas, int columnas, int contadorFilas, int columnaActual) {
        if (contadorFilas == filas) {
            return;
        }
        
        if (columnaActual == columnas) {
            System.out.println();
            dibujarRectangulo2(filas, columnas, contadorFilas + 1, 0);
        } else {
            if (contadorFilas == 0 || contadorFilas == filas - 1 || columnaActual == 0 || columnaActual == columnas - 1) {
                System.out.print("[ ]");
            } else {
                System.out.print("[ ]");
            }
            
            dibujarRectangulo2(filas, columnas, contadorFilas, columnaActual + 1);
        }
    }
    
}

