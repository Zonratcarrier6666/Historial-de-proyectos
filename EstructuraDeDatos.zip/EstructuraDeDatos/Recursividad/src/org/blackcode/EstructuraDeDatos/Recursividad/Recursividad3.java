package org.blackcode.EstructuraDeDatos.Recursividad;
public class Recursividad3 {
        public static void dibujarRectangulo(int filas, int columnas, int contadorFilas) {
        if (contadorFilas == filas) {
            return;
        }

        dibujarFila(columnas, 0, contadorFilas);
        System.out.println();

        dibujarRectangulo(filas, columnas, contadorFilas + 1);
    }

    public static void dibujarFila(int columnas, int contadorColumnas, int contadorFilas) {
        if (contadorColumnas == columnas) {
            return;
        }

        if (contadorFilas == 0 || contadorFilas == (columnas - 1) || contadorColumnas == 0 || contadorColumnas == (columnas - 1)) {
            System.out.print("[ ]");
        } else {
            System.out.print("[ ]");
        }

        dibujarFila(columnas, contadorColumnas + 1, contadorFilas);
    }
    // Esto va en el main
//     Scanner read = new Scanner(System.in);
//        
//        System.out.print("Ingrese el número de filas: ");
//        int filas = read.nextInt();
//        
//        System.out.print("Ingrese el número de columnas: ");
//        int columnas = read.nextInt();
//        
//        dibujarRectangulo(filas, columnas, 0);
        
}
