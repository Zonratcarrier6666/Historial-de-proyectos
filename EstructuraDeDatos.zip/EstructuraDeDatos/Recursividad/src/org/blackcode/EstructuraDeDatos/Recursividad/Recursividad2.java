package org.blackcode.EstructuraDeDatos.Recursividad;

import javax.swing.JOptionPane;
import javax.swing.JOptionPane;

public class Recursividad2 {

    public static int numeroFibonacci(int n) {
        if (n == 0) {
            return 0;
        } else if (n == 1) {
            return 1;
        }

//            System.out.print(n);
//            int numeroFibonacciBuscado= numeroFibonacci(n - 1) + numeroFibonacci(-1);
//            int resultado= numeroFibonacciBuscado + numeroFibonacci(n) ;
//            return numeroFibonacciBuscado;
        return numeroFibonacci(n - 1) + numeroFibonacci(n - 2);
    }

    public static int sumaNaturalesRecursiva(int n) {
        if (n < 0) {
            System.out.println(n);
            return 0;
        } else {
            return n + sumaNaturalesRecursiva(n - 1);
        }
    }

//    public static void escribe(int i, int n, int suma, int contador) {
//
//        if (i <= n) {
////            n = Integer.parseInt(JOptionPane.showInputDialog("escribe un numero"));
//            System.out.println(i);
//            escribe(i + 2, n, suma + i, contador + 1);
//        } else {
//            System.out.println("cantador de pares " + contador + " "
//                    + "sumador de pares " + suma + " "
//                    + "promedi0 " + suma / contador
//            );
////        }
    public static int factorial(int n) {
        // Caso base: si n es igual a 0 o 1, el factorial es 1
        if (n == 0 || n == 1) {
            return 1;
        } // Caso recursivo: calcular el factorial de n multiplicando n por el factorial de n-1
        else {
            return n * factorial(n - 1);
        }
    }

    public static void digitos(int n) {
        if (n < 0) {
        } else {
            digitos(n / 10);
        }
        System.out.println("Los digitos fueron:" + n++);
    }

    public static void digitos2(int n, int i) {
        if (n != 0) {
            digitos2(n / 10, i + 1);
        } else {
            System.out.println("Los digitos fueron:" + i);
        }

    }

    public static int digitos3(int n) {
        if (n <= 0) {
            return 0;
        }
        return 1 + digitos3(n / 0);
    }
    ///Desarrolla un programa con metodo recusrivo que lea un numero e indique cuantos digitos tiene

    public static void escribirRectanguloF(int fila, int F) {
        if (F >= fila) {
            escribirRectanguloF(fila,F + 1);

        } else {
            System.out.print("[]");
            System.out.println();
        }

    }
    public static void escribirRectanguloC(int column, int C) {
        if (C >= column) {
            escribirRectanguloF(column,C + 1);

        } else {
            System.out.print("[]");
            System.out.println();
        }

    }
}
