
package org.blackcode.EstructuraDeDatos.Recursividad;

public class ControladorArreglos {

    public static void main(String[] args) {
            String[] studentNames = {"polo", "Rosario", "Puga", "Esmeralda", "Marco", "Kimberly",
                "Andrea", "Ari", "Angel", "Esteban", "Lluvia", "Socorro", "Angela", "Daniela", "Azul"};

        // Ajustar el tamaño de la matriz groups para que pueda contener todos los elementos de studentNames
        String[][] groups = new String[5][3]; // Cambiamos el tamaño a 5x3

        int x = 0;
        for (int i = 0; i < groups.length; i++) {
            for (int j = 0; j < groups[i].length && x < studentNames.length; j++) {
                groups[i][j] = studentNames[x];
                x++;
            }
        
        }
        for (String[] row : groups) {
            for (String name : row) {
                System.out.print(name + "\t");
            }
            System.out.println();
        }
    }
}






    
    

