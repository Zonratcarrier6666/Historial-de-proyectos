/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package org.blackcode.EstructuraDeDatos.Recursividad;

import static org.blackcode.EstructuraDeDatos.Recursividad.Recursiviad1.dibujarRectangulo;
import static org.blackcode.EstructuraDeDatos.Recursividad.Recursiviad1.dibujarRectangulo2;

/**
 *
 * @author angel
 */
public class MainRectangulos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int filas = 5;
        int columnas = 7;

        System.out.println("Dibujar Rectángulo:");
        dibujarRectangulo(filas, columnas, 0);

        System.out.println("\nDibujar Rectángulo 2:");
        dibujarRectangulo2(filas, columnas, 0, 0);
    }
    
}
