package org.blackcode.EstructuraDeDatos.Recursividad;
import java.util.Scanner;
import static org.blackcode.EstructuraDeDatos.Recursividad.Recursiviad1.dibujarRectangulo2;
import static org.blackcode.EstructuraDeDatos.Recursividad.Recursiviad1.dibujarRectangulo;
import static org.blackcode.EstructuraDeDatos.Recursividad.Recursividad2.escribirRectanguloF;
import static org.blackcode.EstructuraDeDatos.Recursividad.Recursividad2.escribirRectanguloC;
import static org.blackcode.EstructuraDeDatos.Recursividad.Recursividad2.sumaNaturalesRecursiva;
import static org.blackcode.EstructuraDeDatos.Recursividad.Recursividad2.factorial;
import static org.blackcode.EstructuraDeDatos.Recursividad.Recursividad2.numeroFibonacci;
public class Controlador {

    public static void main(String[] args) {
//        int numero = 5;
//        int resultado = factorial(numero);
//        System.out.println("El factorial de " + numero + " es: " + resultado);
//
//        int n = 5;
//        int res = sumaNaturalesRecursiva(n);
//        System.out.println("Los numeros naturales son: " + res);
//        digitos2(346, 0);
//        Scanner leer=new Scanner(System.in);
//        System.out.println("Introduc un numero");
//        int n=leer.nextInt();
//        System.out.println("El numero tiene: "+n+"Tiene"+digitos3(n)+"Digitos");
//        int numeroF=4;
//        int result = numeroFibonacci(numeroF);
//        System.out.println("el numero fibonaccio es "+result);


// Scanner read = new Scanner(System.in);
//        
//        System.out.print("Ingrese el número de filas: ");
//        int filas = read.nextInt();
//        
//        System.out.print("Ingrese el número de columnas: ");
//        int columnas = read.nextInt();
//        
//        dibujarRectangulo(filas, columnas, 0);
//        

//Scanner scanner = new Scanner(System.in);
//        
//        System.out.print("Ingrese la cantidad de filas: ");
//        int filas = scanner.nextInt();
//        
//        System.out.print("Ingrese la cantidad de columnas: ");
//        int columnas = scanner.nextInt();
//       
//            dibujarRectangulo2(filas, columnas, 0,0);

//for(int i=0; i<fila;i++){
//for(int j=0;j<column;j++){
//    System.out.print("[]");
//}
//    System.out.println();
//}


    }
    
}
