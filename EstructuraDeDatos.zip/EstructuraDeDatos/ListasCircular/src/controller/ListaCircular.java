/*
 LISTAS CIRCULARES
¿Que Son?
Son listas las cuales nunca se acaban, debido a que no tiene ningun nodo que este 
apuntando a NULL

CARACTERISTICAS
-el último elemento de la lista apunta de nuevo al primer elemento, formando un ciclo cerrado. 
 Esto significa que no hay un final claramente definido en una lista circular, ya que los elementos
 están interconectados en un bucle.
-Puedes acceder a los elementos en ambas direcciones, ya que no hay un principio
 o final fijo.
-las operaciones de inserción y eliminación se pueden realizar en cualquier posición de la lista, ya que
 no hay un punto final fijo.
-No existe un final; cuando llegas al último elemento, el siguiente elemento es el primer elemento de la lista.

 */
package controller;

/**
 *
 * @author angel
 */
public class ListaCircular {

    private Nodo inicio;
    private int tamanio;
    private Nodo ultimo;

    public ListaCircular() {
        inicio = null;
        ultimo = null;
        tamanio = 0;
    }
//Usamos este metodo para comprobar si no esta vacia.

    public boolean esVacia() {
        return inicio == null;
    }
//Se usa para regresar el tamaño de lista.

    public int getTamanio() {
        return tamanio;
    }
// Se usa para eliminar, pero aqui solo inicializamos las variables.

    public void eliminar() {
        inicio = null;
        ultimo = null;
        tamanio = 0;
    }

    public void agregarAlFinal(int valor) {
        //primero agregamos un objeto de tipo Nodo el cual se va a agregar.
        Nodo nuevo = new Nodo();
        // se agrega el valor que se le va dar.
        nuevo.setValor(valor);
        // Se comprueba que la lista no este vacia.
        if (esVacia()) {
            //Asignamos inicia = nuevo; osea que si esta vacia agregara un valor al inicio.
            inicio = nuevo;
            // Aqui vemos una caracteristica de las listas circulares lo cual es que el ultimo nodo apunta a
            // nuevo o para mas facil de entender a inicio.
            ultimo = nuevo;
            ultimo.setSiguiente(inicio);
        } else {
            //Si no esta vacia el nuevo se apunta a ultimo y se apunta a inicio
            //por lo tanto se agrega el nuevo nodo en final o al ultimo.
            ultimo.setSiguiente(nuevo);
            nuevo.setSiguiente(inicio);
            ultimo = nuevo;
        }
        // aumenta un contador "tamanio" para saber la longitud la lista.
        tamanio++;
    }

    public void agregarAlInicio(int valor) {
        Nodo nuevo = new Nodo();
        nuevo.setValor(valor);
        if (esVacia()) {
            //Asignamos inicia = nuevo; osea que si esta vacia agregara un valor al inicio.
            inicio = nuevo;
            // Aqui vemos una caracteristica de las listas circulares lo cual es que el ultimo nodo apunta a
            // nuevo o para mas facil de entender a inicio.
            ultimo = nuevo;
            ultimo.setSiguiente(inicio);
        } else {
            //Si no esta vacia el nuevo se apunta a ultimo y se apunta a inicio
            //por lo tanto se agrega el nuevo nodo al inicio osea sera el primero de la lista.
            nuevo.setSiguiente(inicio);
            inicio = nuevo;
            ultimo.setSiguiente(nuevo);
        }
        // aumenta un contador "tamanio" para saber la longitud la lista.
        tamanio++;
    }
//Muestra la lista 

    public void listar() {
        //Primero se chaca que la lista no este vacia,  
        if (!esVacia()) {
            // Esto se hace para poder o coocar el inicio del recorrido al inicio de la lista
            Nodo aux = inicio;
            // Es para ponerle un indice a los nodos
            int i = 0;
            // Es para rcorrer aal menos  una vez la lista.
            do {
                //Aqui vamos a impimir cada interaccion que se hizo dentro de este DO-WHILE.
                //Lo cual nos mostrara la lista
                System.out.print(i + ".[" + aux.getValor() + "]" + "-->");
                aux = aux.getSiguiente();
                i++;
            } while (aux != inicio);
            //Imprimiremos el contador con su respectivo nodo
            System.out.println("null\n");
            System.out.println("Tamaño de la lista" + tamanio);
        }
    }

    public void insertarPorReferencia(int referencia, int valor) {
        Nodo nuevo = new Nodo();
        nuevo.setValor(valor);
        if (!esVacia()) {
            if (buscar(referencia)) {
                Nodo aux = inicio;
                while (aux.getValor() != referencia) {
                    aux = aux.getSiguiente();
                }
                if (aux == ultimo) {
                    // Apuntamos con el ultimo nodo de la lista al nuevo.
                    aux.setSiguiente(nuevo);
                    // Apuntamos con el nuevo nodo al inicio de la lista.
                    nuevo.setSiguiente(inicio);
                    // Como ahora como el nuevo nodo es el ultimo se actualiza
                    // la variable ultimo.
                    ultimo = nuevo;
                } else {
                    // Crea un respaldo de la continuación de la lista.
                    Nodo siguiente = aux.getSiguiente();
                    // Enlaza el nuevo nodo despues del nodo de referencia.
                    aux.setSiguiente(nuevo);
                    // Une la continuacion de la lista al nuevo nodo.
                    nuevo.setSiguiente(siguiente);
                }
                // Incrementa el contador de tamaño de la lista.
                tamanio++;
            }
        }
    }

    public void insertarPorPosicion(int posicion, int valor) {
        if (posicion >= 0 && posicion <= tamanio) {
            Nodo nuevo = new Nodo();
            nuevo.setValor(valor);
            if (posicion == 0) {
                nuevo.setSiguiente(inicio);
                inicio = nuevo;
                ultimo.setSiguiente(inicio);
            } else {
                if (posicion == tamanio) {
                    ultimo.setSiguiente(nuevo);
                    nuevo.setSiguiente(inicio);
                    ultimo = nuevo;
                } else {
                    Nodo aux = inicio;
                    for (int i = 0; i < (posicion - 1); i++) {
                        aux = aux.getSiguiente();
                    }
                    Nodo siguiente = aux.getSiguiente();
                    aux.setSiguiente(nuevo);
                    nuevo.setSiguiente(siguiente);
                }
            }
            tamanio++;
        }
    }

    public int getValor(int posicion) throws Exception {
        if (posicion >= 0 && posicion < tamanio) {
            if (posicion == 0) {
                return inicio.getValor();
            } else {
                Nodo aux = inicio;
                for (int i = 0; i < posicion; i++) {
                    aux = aux.getSiguiente();
                }
                return aux.getValor();
            }
        } else {
            throw new Exception("Posición inexistente en la lista.");
        }
    }

    public boolean buscar(int referencia) {
        Nodo aux = inicio;
        boolean encontrado = false;
        do {
            if (referencia == aux.getValor()) {
                encontrado = true;
            } else {
                aux = aux.getSiguiente();
            }
        } while (aux != inicio && encontrado != true);
        return encontrado;
    }

    public int getPosicion(int referencia) throws Exception {
        if (buscar(referencia)) {
            Nodo aux = inicio;
            int cont = 0;
            while (referencia != aux.getValor()) {
                cont++;
                aux = aux.getSiguiente();
            }
            return cont;
        } else {
            throw new Exception("Valor inexistente en la lista.");
        }
    }

    public void editarPorReferencia(int referencia, int valor) {
        if (buscar(referencia)) {
            Nodo aux = inicio;
            while (aux.getValor() != referencia) {
                aux = aux.getSiguiente();
            }
            aux.setValor(valor);
        }
    }

    public void editarPorPosicion(int posicion, int valor) {
        if (posicion >= 0 && posicion < tamanio) {
            if (posicion == 0) {
                inicio.setValor(valor);
            } else {
                Nodo aux = inicio;
                for (int i = 0; i < posicion; i++) {
                    aux = aux.getSiguiente();
                }
                aux.setValor(valor);
            }
        }
    }

    public void removerPorRferencia(int referencia) {
        if (buscar(referencia)) {
            if (inicio.getValor() == referencia) {
                inicio = inicio.getSiguiente();
                ultimo.setSiguiente(inicio);
            } else {
                Nodo aux = inicio;
                while (aux.getSiguiente().getValor() != referencia) {
                    aux = aux.getSiguiente();
                }
                if (aux.getSiguiente() == ultimo) {
                    aux.setSiguiente(inicio);
                    ultimo = aux;
                } else {
                    // Guarda el nodo siguiente del nodo a eliminar.
                    Nodo siguiente = aux.getSiguiente();
                    // Enlaza el nodo anterior al de eliminar con el 
                    // sguiente despues de el.
                    aux.setSiguiente(siguiente.getSiguiente());
                    // Actualizamos el puntero del ultimo nodo
                }
            }
            tamanio--;
        }
    }

    public void removerPorPosicion(int posicion) {
        if (posicion >= 0 && posicion < tamanio) {
            if (posicion == 1) {
                inicio = inicio.getSiguiente();
                ultimo.setSiguiente(inicio);
            } else {
                Nodo aux = inicio;
                for (int i = 0; i < posicion-1; i++) {
                    aux = aux.getSiguiente();
                }
                if (aux.getSiguiente() == ultimo) {
                    aux.setSiguiente(inicio);
                    ultimo = aux;
                } else {
                    // Guarda el nodo siguiente del nodo a eliminar.
                    Nodo siguiente = aux.getSiguiente();
                    // Enlaza el nodo anterior al de eliminar con el 
                    // sguiente despues de el.
                    aux.setSiguiente(siguiente.getSiguiente());
                    // Actualizamos el puntero del ultimo nodo
                }
            }
        }
        tamanio--;
    }
}
