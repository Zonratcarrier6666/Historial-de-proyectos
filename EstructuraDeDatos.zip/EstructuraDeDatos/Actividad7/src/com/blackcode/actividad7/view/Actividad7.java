package com.blackcode.actividad7.view;

import com.blackcode.actividad7.model.Automovil;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author angel
 */
public class Actividad7 {

    public static void main(String[] args) {
        //CREAMOS LA LISTA "listaDeAutooviles"
        List<Automovil> listaDeAutomoviles = new ArrayList<>();
        System.out.println("//////////EJEMPLO DE isEmpty() parte 1////////////");
        /*METODO: isEmpty()
    Nombre : isEmpty
    Parametros: no tiene
    tipo: boolean
    Descripcion: "DEVUELVE TRUE" si esta lista no contiene elementos.
    Explicacion: si tenemos una lista llamada figuras y tiene dentro ("cuadrado","Triangulo","Circulo")
                 este metodo nos devuelve un "TRUE", pero si la lista figuras esta  asi () devuelve un 
                 "FALSE"
    Uso:nombreLista.isEmpty();
    Ejemplo:*/

        boolean estaVacia = listaDeAutomoviles.isEmpty();

        if (estaVacia) {
            System.out.println("La lista de automóviles está vacía.");
        } else {
            System.out.println("La lista de automóviles ya no está vacía.");
        }
        System.out.println("//////////EJEMPLO DE add(E e)////////////");
        /**
         * METODO: add(E e) Nombre : add Parametros: "E" que el tipo de dato y
         * "e" el nombre Descripcion: Agrega el elemento especificado al "FINAL
         * DE LA LISTA". } Explicacion: se van agregando al final, esta implica
         * que cada que agregemos el "1" sera el ultimo, y sia agregamos "2"
         * este pasara a ser el ultimo de la lista y asi hasta que se se acabe
         * de agregar elementos a la lista Uso: nombredeLista.add(E e); Ejemplo:
         */
        // Crear instancias de objetos Automovil
        Automovil auto1 = new Automovil("Nissan", "Tsuru", 12345, 50000.5f);
        Automovil auto2 = new Automovil("Mazda", "RX-6", 67890, 60000.0f);
        Automovil auto3 = new Automovil("Oshkosh", "SandCat", 66666, 100000.0f);

        // Agregar objetos Automovil a la lista usando el método add(E e)
        listaDeAutomoviles.add(auto1);
        listaDeAutomoviles.add(auto2);
        listaDeAutomoviles.add(auto3);

        // Recorrer la lista y mostrar la información de los automóviles
        for (Automovil automovil : listaDeAutomoviles) {
            System.out.println("Marca: " + automovil.getMarca());
            System.out.println("Modelo: " + automovil.getModelo());
            System.out.println("Placas: " + automovil.getPlacas());
            System.out.println("Kilometros: " + automovil.getKilometros());

        }
        System.out.println("//////////EJEMPLO DE isEmpty() parte 2////////////");
        estaVacia = listaDeAutomoviles.isEmpty();

        if (estaVacia) {
            System.out.println("La lista de automóviles está vacía.");
        } else {
            System.out.println("La lista de automóviles ya no está vacía.");
        }

        System.out.println("//////////EJEMPLO DE add(int index, E element)////////////");
        /*METODO: add(int index, E element)
    Nombre :add
    Parametros:
        -Index: es el indice dde la lista, por dfecto todas las lista ya traen el suyo, este empieza del 0
        -E:es lo que vas agrgar, para este ejemploe es un auto
    tipo: void
    Descripcion: "INSERTA" el elemento "ESPECIFICADO EN LA POSICION ESPECIFICADA" en esta lista.
    Explicacion: cuando hacemos una insercion y especifiacams la posicion, insertamos de maneara mas concreta los
                 Elementos ya que podemos elegir en donde iran nuestros elementos, si yo tengo una lista numeros
                   donde hay 3 numeros (1,2,3) y quiero insertar el cuatro en la posicion del nuero 2, debemos
                   hacer nuestra insercion especificando el indice osea numeros.add(1,4); y la lista quedaria si
                   (1,4,2,3).
    Uso: nombreLista.add(int indice(numero de posicion),lo que vas a agregar);
    Ejemplo:*/
// Agregar un nuevo automóvil en la posición 1
        Automovil auto4 = new Automovil("Mercedes Benz", "AMG GT 4-Door Coupé", 54321, 40000.0f);
        listaDeAutomoviles.add(1, auto4);
        System.out.println(listaDeAutomoviles);
        System.out.println("//////////EJEMPLO DE size()////////////");
        /**
         * METODO: size(); Nombre : size Parametros: no tiene tipo: int
         * Descripcion: "DEVUELVE EL NUMERO DE ELEMENTOS EN UNA LISTA".
         * Explicacion: cuenta las posiciones de la lista (index) y nos da el
         * resultado de la longitud de nuestra lista Ejemplo:
         */
        int tamanoLista = listaDeAutomoviles.size();
        System.out.println("El tamaño de la lista de automóviles es: " + tamanoLista);
         System.out.println("//////////toArray(T[] a)////////////");
        /**
         * METODO: toArray(T[]a); 
         * Nombre : toArray 
         * Parametros: 
         * -T[] Este
         * parámetro representa la matriz en la que se almacenarán los elementos
         * de la lista. 
         * -a Si la matriz a pasada como argumento tiene la
         * capacidad suficiente para contener todos los elementos de la lista,
         * se utilizará esa matriz. De lo contrario, se creará una nueva matriz
         * del mismo tipo que a. 
         * tipo: <T> T[] 
         * Descripcion: Devuelve una matriz que contiene todos los elementos de esta lista en la secuencia
         * adecuada (del primero al último elemento); el tipo de tiempo de ejecución de la matriz devuelta es 
         * el de la matriz especificada.
         * Explicacion: ????????????
         * Ejemplo:
         */
        Automovil[] arregloDeAutomoviles = listaDeAutomoviles.toArray(new Automovil[0]);

        for (Automovil automovil : arregloDeAutomoviles) {
            System.out.println(automovil);
        }
        System.out.println("//////////EJEMPLO DE remove(Object o)////////////");
        /*METODO: remove(Object o)
    Nombre : remove
    Parametros: Object o, es un objeto de tipo object
    tipo: boolean
    Descripcion: "ElLIMINA" la primera aparición del elemento especificado de esta lista, si está presente.
    Explicacion:  Este elimina la primera aparacion, lo que quiere decir que si tenemos elementos repetidos
                  se elimina el primero que esta en la lsita
                  por ejemplo, teneos una lista de llamada ""
    Uso: nombreLista.remove(int index,E element)
    Ejemplo:*/
        // Crear un objeto Automovil para eliminar de la lista
        Automovil autoAEliminar = new Automovil("Mazda", "RX-6", 67890, 60000.0f);

        // Eliminar el objeto 'autoAEliminar' de la lista
        boolean eliminado = listaDeAutomoviles.remove(autoAEliminar);

        if (eliminado) {
            System.out.println("Se ha eliminado el automóvil de la lista.");
        } else {
            System.out.println("El automóvil no se encontraba en la lista.");
        }

        // Mostrar la lista después de la eliminación
        System.out.println("Lista después de la eliminación:");
        for (Automovil automovil : listaDeAutomoviles) {
            System.out.println(automovil);
        }
        System.out.println("//////////EJEMPLO DE remove(int index)////////////");
        /*METODO: remove(int index)
    Nombre :remove
    Parametros: int index
    tipo: E
    Descripcion: Elimina el elemento en la posición especificada en esta lista.
    Explicacion: funciona igual que el add(int index, E element) pero este solo borra
    Uso:nombreLista.remove(int index);
    Ejemplo:*/
        // Eliminar un automóvil en la posición 1 (índice 1)
        listaDeAutomoviles.remove(1);

        // Mostrar la lista después de eliminar un automóvil
        System.out.println("\nLista después de eliminar un automóvil en la posicion (1):");
        for (Automovil automovil : listaDeAutomoviles) {
            System.out.println(automovil);
        }
        System.out.println("//////////EJEMPLO DE clear()////////////");
        /*METODO: clear()
    Nombre : clear
    Parametros: no tiene
    tipo: void
    Descripcion: "ELIMINA TODOS" los elementos de esta lista.
    Explicacion: pues nomas elimina todos los elementos de la lista osea ya no hay nada dentro.
    Uso: nombreLista.clear();
    Ejemplo:
         */
// Mostrar la lista antes de la eliminación
        System.out.println("Lista antes de clear: " + listaDeAutomoviles);

        // Usar clear() para eliminar todos los elementos
        listaDeAutomoviles.clear();
        System.out.println("////////////// Ejemplo aplicado de isEmpty()//////////");
        estaVacia = listaDeAutomoviles.isEmpty();
        if (estaVacia) {
            System.out.println(" ya no hay autos");

        } else {
            System.out.println("aun hay autos....");
        }
        // Mostrar la lista después de la eliminación
        System.out.println("Lista después de clear: " + listaDeAutomoviles);
        System.out.println();

    }
}
/*
Clase Automavil para practicar el ArrayList
public class Automovil {
    private String marca;
    private String modelo;
    private int placas;
    private float kilometros;

    public Automovil() {
    }

    public Automovil(String marca, String modelo, int placas, float kilometros) {
        this.marca = marca;
        this.modelo = modelo;
        this.placas = placas;
        this.kilometros = kilometros;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String Modelo) {
        this.modelo = Modelo;
    }

    public int getPlacas() {
        return placas;
    }

    public void setPlacas(int placas) {
        this.placas = placas;
    }

    public float getKilometros() {
        return kilometros;
    }

    public void setKilometros(float kilometros) {
        this.kilometros = kilometros;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Automovil other = (Automovil) obj;
        return this.marca.equals(other.marca) &&
               this.modelo.equals(other.modelo) &&
               this.placas == other.placas &&
               this.kilometros == other.kilometros;
    }

    @Override
    public String toString() {
    return "Automovil{" + 
           "\n  Marca=" + marca + 
           "\n  Modelo=" + modelo + 
           "\n  Placas=" + placas + 
           "\n  Kilometros=" + kilometros + 
           "\n}";
    }
    
}
*/