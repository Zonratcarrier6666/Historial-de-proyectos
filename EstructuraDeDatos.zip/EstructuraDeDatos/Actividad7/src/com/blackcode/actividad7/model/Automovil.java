
package com.blackcode.actividad7.model;

/**
 *
 * @author angel
 */
public class Automovil {
    private String marca;
    private String modelo;
    private int placas;
    private float kilometros;

    public Automovil() {
    }

    public Automovil(String marca, String modelo, int placas, float kilometros) {
        this.marca = marca;
        this.modelo = modelo;
        this.placas = placas;
        this.kilometros = kilometros;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String Modelo) {
        this.modelo = Modelo;
    }

    public int getPlacas() {
        return placas;
    }

    public void setPlacas(int placas) {
        this.placas = placas;
    }

    public float getKilometros() {
        return kilometros;
    }

    public void setKilometros(float kilometros) {
        this.kilometros = kilometros;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Automovil other = (Automovil) obj;
        return this.marca.equals(other.marca) &&
               this.modelo.equals(other.modelo) &&
               this.placas == other.placas &&
               this.kilometros == other.kilometros;
    }

    @Override
    public String toString() {
    return "Automovil{" + 
           "\n  Marca=" + marca + 
           "\n  Modelo=" + modelo + 
           "\n  Placas=" + placas + 
           "\n  Kilometros=" + kilometros + 
           "\n}";
    }
    
}
