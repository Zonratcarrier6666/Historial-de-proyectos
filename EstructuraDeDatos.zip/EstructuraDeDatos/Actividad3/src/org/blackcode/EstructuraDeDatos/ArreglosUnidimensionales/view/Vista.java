
package org.blackcode.EstructuraDeDatos.ArreglosUnidimensionales.view;

import java.util.Scanner;
import org.blackcode.EstructuraDeDatos.ArreglosUnidimensionales.core.Controlador;
import org.blackcode.EstructuraDeDatos.ArreglosUnidimensionales.model.Estudiante;

public class Vista {
    public static void main(String[] args) {
        Controlador controlador = new Controlador();
        Scanner leer = new Scanner(System.in);
        while (true) {
            System.out.println("¿Qué quieres hacer?");
            System.out.println("(1) Agregar Estudiante");
            System.out.println("(2) Eliminar Estudiante");
            System.out.println("(3) Modificar Estudiante");
            System.out.println("(4) Listar Estudiantes");
            System.out.println("(5) Buscar Estudiante");
            System.out.println("(6) Ordenar Estudiantes");
            System.out.println("(7) Busqueda Binaria");
            System.out.println("(8) Salir");

            int eleccion = leer.nextInt();
            leer.nextLine(); // Consumir el salto de línea pendiente

            switch (eleccion) {
                case 1:
                    System.out.println("Ingresa los datos del nuevo estudiante");
                    System.out.println("Ingresa el ID del estudiante:");
                    int id = 0;
                    boolean idValido = false;
                    while (!idValido) {
                        try {
                            id = Integer.parseInt(leer.nextLine());
                            idValido = true;
                        } catch (NumberFormatException e) {
                            System.out.println("ID no válido. Ingresa un ID válido:");
                        }
                    }

                    System.out.println("Ingresa el nombre del estudiante:");
                    String nombre = leer.nextLine();

                    System.out.println("Ingresa la edad del estudiante:");
                    byte edad = 0;
                    boolean edadValida = false;
                    while (!edadValida) {
                        try {
                            edad = Byte.parseByte(leer.nextLine());
                            edadValida = true;
                        } catch (NumberFormatException e) {
                            System.out.println("Edad no válida. Ingresa una edad válida:");
                        }
                    }

                    System.out.println("Ingresa el correo del estudiante:");
                    String correo = leer.nextLine();

                    controlador.agregarEstudiante(id, nombre, edad, correo);
                    break;
                case 2:
                    System.out.println("Ingresa el ID del estudiante a eliminar:");
                    int ide = 0;
                    boolean idValidoE = false;
                    while (!idValidoE) {
                        try {
                            ide = Integer.parseInt(leer.nextLine());
                            idValidoE = true;
                        } catch (NumberFormatException e) {
                            System.out.println("ID no válido. Ingresa un ID válido:");
                        }
                    }
                    controlador.eliminarEstudiante(ide);
                    break;
                case 3:
                    System.out.println("Ingresa el ID del estudiante a modificar:");
                    int idM = 0;
                    boolean idValidoM = false;
                    while (!idValidoM) {
                        try {
                            idM = Integer.parseInt(leer.nextLine());
                            idValidoM = true;
                        } catch (NumberFormatException e) {
                            System.out.println("ID no válido. Ingresa un ID válido:");
                        }
                    }

                    System.out.println("Ingresa el nuevo nombre:");
                    String nombreM = leer.nextLine();

                    System.out.println("Ingresa la nueva edad:");
                    byte edadM = 0;
                    boolean edadValidaM = false;
                    while (!edadValidaM) {
                        try {
                            edadM = Byte.parseByte(leer.nextLine());
                            edadValidaM = true;
                        } catch (NumberFormatException e) {
                            System.out.println("Edad no válida. Ingresa una edad válida:");
                        }
                    }

                    System.out.println("Ingresa el nuevo correo:");
                    String correoM = leer.nextLine();

                    controlador.modificarEstudiante(idM, nombreM, edadM, correoM);
                    break;
                case 4:
                    System.out.println("Lista de Estudiantes:");
                    controlador.listarEstudiantes();
                    break;
                case 5:
                    System.out.println("Ingresa el ID del estudiante que deseas buscar:");
                    int idB = 0;
                    boolean idValidoB = false;
                    while (!idValidoB) {
                        try {
                            idB = Integer.parseInt(leer.nextLine());
                            idValidoB = true;
                        } catch (NumberFormatException e) {
                            System.out.println("ID no válido. Ingresa un ID válido:");
                        }
                    }
                    Estudiante estudianteBuscado = controlador.buscarEstudiantePorId(idB);
                    controlador.imprimirEstudiante(estudianteBuscado);
                    break;
                case 6:
                    System.out.println("Lista ordenada por ID:");
                    controlador.ordenarEstudiantes();
                    break;
                case 7:
                    System.out.println("Ingresa el ID del estudiante que deseas buscar (búsqueda binaria específica):");
                    int idBinarioEspecifico = 0;
                    boolean idValidoBinarioEspecifico = false;
                    while (!idValidoBinarioEspecifico) {
                        try {
                            idBinarioEspecifico = Integer.parseInt(leer.nextLine());
                            idValidoBinarioEspecifico = true;
                        } catch (NumberFormatException e) {
                            System.out.println("ID no válido. Ingresa un ID válido:");
                        }
                    }
                    Estudiante estudianteEncontradoEspecifico = controlador.buscarEstudianteBinarioEspecifico(idBinarioEspecifico);
                    if (estudianteEncontradoEspecifico != null) {
                        System.out.println("Estudiante encontrado:");
                        System.out.println(estudianteEncontradoEspecifico);
                    } else {
                        System.out.println("Estudiante no encontrado.");
                    }
                    break;
                case 8:
                    System.out.println("Usted ha salido del sistema.");
                    leer.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Opción no válida. Inténtalo de nuevo.");
                    break;
            }
        }
    }
}
