
package org.blackcode.EstructuraDeDatos.ArreglosUnidimensionales.model;

public class Estudiante {
    private int id;
    private String nombre;
    private byte edad;
    private String correo;
    
    public Estudiante(int id, String nombre, byte edad, String correo) {
        this.id = id;
        this.nombre = nombre;
        this.edad = edad;
        this.correo = correo;
    }
    public Estudiante() {
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public byte getEdad() {
        return edad;
    }

    public void setEdad(byte edad) {
        this.edad = edad;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    @Override
    public String toString() {
        return "Datos de estudiante" 
                +"\nid="+id+"\nnombre="+nombre+"\nedad=" + edad + "\ncorreo=" + correo;
    }
}
