package org.blackcode.EstructuraDeDatos.ArreglosUnidimensionales.core;

import org.blackcode.EstructuraDeDatos.ArreglosUnidimensionales.model.Estudiante;

public class Controlador {

    private int n = 0;
    private Estudiante listaEstudiantes[] = new Estudiante[10];
//Metodo para agregar al estudiante
    public void agregarEstudiante(int id, String nombre, byte edad, String correo) {
        if (n == listaEstudiantes.length) {
            // A qui comparamos si n es igual a longuitud de listaEstudiantes,y si estan iguales se significa 
            // que pues ya esta lleno.
            Estudiante[] nuevoEstudiante = new Estudiante[listaEstudiantes.length * 2];
            // Copia los elementos del arreglo listaEstudiantes y crea a uno nuevo que tenga el doble de espacio
            // Osea que si llenamos un arreglo de 10 y quremos poner el onceavo (el numero en el arreglo 9) estudiante se copia 
            // los estudiante del arreglo de 10 y se cea un arrreglo que se llama nuevoEstudiante el cual tendra 
            // los 10 estudiantes de listaEstudiantes y el onceavo estudiante (el 10 en el nuevo arreglo nuevoEtudiante)
            // pero ademas tendra el doble de tamaño de listaEstudiante ya que multiplicamos el tamaño (.length) por 2
            ///A esto se le llama un arreglo dinamico///
            System.arraycopy(listaEstudiantes, 0, nuevoEstudiante, 0, listaEstudiantes.length);
            // Reemplaza el arreglo original con el nuevo arreglo
            listaEstudiantes = nuevoEstudiante;
            // por ultimo le damos el valor de nuevoEstudiante (el que trae todo el merequentenge) a el arreglo principal 
            // listaEstudiantes
        }

        listaEstudiantes[n] = new Estudiante(id, nombre, edad, correo);
        // Aqui listaEstudiantes solo se incrementa y agregamos los datos del nuevo estudiante (nuevo objeto)
        // y se le dan los parametros par asu llenado
        n++;
        // n se increnta por si sola agregando a los estudiambres
        System.out.println("Estudiante agregado correctamente.");
    }
//Metodo para primero buscar(for) y despues eliminar al estudiante 
    public void eliminarEstudiante(int ide) {
        int indice = -1;

        // cada vuelta del for verifica si el "i" esta en la posicion en el arreglo
        // Osea se que checa que no este vacio o de que haya un estudiante en el arreglo
        for (int i = 0; i < n; i++) {
            if (listaEstudiantes[i] != null && listaEstudiantes[i].getId() == ide) {
                indice = i; // agarramos el id estudiante y guardamos su índice
                break;
            }
        }
        // aca agarramos al indice que contiene, como quien dice el id del estudiante
        // y recorre el arreglo hasta la penultima posicion del arreglo osea que si el arreglo es de 10
        // y en el for anterior lo que se dio 7 vueltas la penultima posicion es la 6
        if (indice != -1) {
            // Si encontramos al estudiante, lo eliminamos y reorganizamos el arreglo
            for (int i = indice; i < n - 1; i++) {
                listaEstudiantes[i] = listaEstudiantes[i + 1];
        // listaEstudiantes[i] = listaEstudiantes[i + 1]; aqui lo que hace es que cuando eliminamos a un wey
        // el que esta antes del wey eliminado lo recorremos a la posicion del wey eliminado 
        // osea que si la posicion del wey "A" eliminado fuera un 2 y la del wey "B" (el que esta despues del wey "A")
        // seria la posicion 3, como eliminamos al wey "A", el wey "B" pasa a estar a la posicion 2
      
            }
            listaEstudiantes[n - 1] = null;
            n--;
            System.out.println("Estudiante dado de baja correctamente.");
            // Lo que pasa aqui es que nos vamos a la ultima posicion del arreglo y le ponemos un valor "null"
            // y "n--;" lo que hace es que disminuye el tamaño del arreglo, Osea que si es de 10 el arreglo pasa a hacr de 
            // de un tamaño de 9
        } else {
            System.out.println("no encontrado.");
            // y pues aqui ya si no encuentra el id pos te dice que no se encontro
        }
    }
//Metodo de modifar estudiantes
    public void modificarEstudiante(int id, String nuevoNombre, byte nuevaEdad, String nuevoCorreo) {
        boolean estudianteEncontrado = false;

        // Buscamos el estudiante por su ID
        for (int i = 0; i < n; i++) {
            if (listaEstudiantes[i] != null && listaEstudiantes[i].getId() == id) {
                // Se busca al estudiante como en el Metodo eliminar
                // y si lo encuntra le damos un valor a la variable estudianteEcontrado de "true"
                estudianteEncontrado = true;

                //Aca Modificamos los datos del estudiante menos id por que pues no
                listaEstudiantes[i].setNombre(nuevoNombre);
                listaEstudiantes[i].setEdad(nuevaEdad);
                listaEstudiantes[i].setCorreo(nuevoCorreo);

                System.out.println("Estudiante modificado correctamente.");
                break;
            }
        }
        // si no se encuntra el id osea que la variable encontrarEstudiante es "false" le manda el mensaje
        // Estudiante no encontrado
        if (estudianteEncontrado==false) {
            System.out.println("Estudiante no encontrado.");
        }
    }

    public Estudiante buscarEstudiantePorId(int id) {
        // Buscamos el id de la misma forma que con el de eliminar
        // pro este retorna al estudiante encontrado
        for (int i = 0; i < n; i++) {
            if (listaEstudiantes[i] != null && listaEstudiantes[i].getId() == id) {
                return listaEstudiantes[i]; // Retorna el estudiante encontrado
            }
        }
        // Si no se encuentra al estudiante, retorna null
        return null;
    }
    
public Estudiante buscarEstudianteBinarioEspecifico(int id) {
    // Asegurarse de que los estudiantes estén ordenados
    int izquierda = 0;
    int derecha = n - 1;

    while (izquierda <= derecha) {
        int medio = izquierda + (derecha - izquierda) / 2;
        if (listaEstudiantes[medio] != null) {
            int idMedio = listaEstudiantes[medio].getId();

            if (idMedio == id) {
                return listaEstudiantes[medio]; // Estudiante encontrado
            }

            if (idMedio < id) {
                izquierda = medio + 1;
            } else {
                derecha = medio - 1;
            }
        }
    }
    return null; // Estudiante no encontrado
}

    public void imprimirEstudiante(Estudiante estudiante) {
        // aqui se hace una "diferencia" si estudiante no es null se toma que si esta en el arreglo por ende 
        // si existe o si se encontro
        if (estudiante != null) {
            System.out.println("Estudiante encontrado:");
            System.out.println(estudiante);
            // si es null ose que no existe pues no se encontro
        } else {
            System.out.println("Estudiante no encontrado.");
        }
    }

    public void listarEstudiantes() {
        // recorre el arreglo verificando que sea diferente de null (que no se nulo pues) si es diferente de null
        // se significa que si hay algun estudiante y como si existe y hay datos de ese wey pues lo imprimimos
        for (int i = 0; i < n; i++) {
            if (listaEstudiantes[i] != null) {
                System.out.println(listaEstudiantes[i]);
            }
        }
    }

    public void ordenarEstudiantes() {
        // de primeras inizialisamos la variableintercambio="false" para saber si se se hicieron cambios en el arreglo
        // y si no, nos da a entender que ya estaban ordenados
        boolean intercambiado ;
        do {
            intercambiado = false;
            for (int i = 0; i < n - 1; i++) {
                if (listaEstudiantes[i] != null && listaEstudiantes[i + 1] != null
                        && listaEstudiantes[i].getId() > listaEstudiantes[i + 1].getId()) {
                    // Intercambia los estudiantes si están fuera de orden por ID
                    Estudiante temp = listaEstudiantes[i];
                    listaEstudiantes[i] = listaEstudiantes[i + 1];
                    listaEstudiantes[i + 1] = temp;
                    intercambiado = true;
                }
            }
        } while (intercambiado);
/// lo que se hace en la parte de arriba es un intercambio de posiciones para que se ordenen osea se que
// se recorre el arregllo y se va comproban que la posicion y el id se ordenen asendentemente 
// ejemplo

// primer vuelta
// Maria[0]=(id=3) 
// PachoPistolas[1}=(id=4)
// LolaLaTrailera[2]=(id=1)
// MikeTyson[3]=(id=2)
// estan en desorden por id veda
// lo que haces es dar vueltas con el for ose que es como si te preguntaran ¿estan en orden?
// pues vas a decir que no veda, entonces los mueves
// Mas mejor explicado el la primera vuelta no se verifican y no estan ordenados asi que se meuven

// segunda vuelta//                
// PachoPistolas[1}=(id=4)
// LolaLaTrailera[2]=(id=1)
// MikeTyson[3]=(id=2)
// Maria[0]=(id=3) 

// tercer vuelta//
// LolaLaTrailera[2]=(id=1)
// MikeTyson[3]=(id=2)
// Maria[0]=(id=3) 
// PachoPistolas[1}=(id=4)
// aca se termina el ciclo y se imprime por que ya estan en orden
        System.out.println("Estudiantes ordenados por ID:");
        for (int i = 0; i < n; i++) {
            if (listaEstudiantes[i] != null) {
                System.out.println(listaEstudiantes[i]);
            }
        }
    }
    public void ordenamientoQshort(){
    
    }
}
