package view;
/**
 * La clase Main es la clase principal del juego del ahorcado. Inicia una instancia de la clase
 * El_Ahorcado y comienza el juego.
 */
import controller.El_Ahorcado;
/**
 *
 * @author angel
 */
public class Main {

    public static void main(String[] args) {
        // Crear una instancia de El_Ahorcado
         El_Ahorcado ahorcado = new El_Ahorcado();
         // Iniciar el juego
        ahorcado.jugar();
    }
}
