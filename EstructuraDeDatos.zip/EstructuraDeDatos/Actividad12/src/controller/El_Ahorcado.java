package controller;

import model.PilaMonigote;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import model.ListaPalabras;
import model.Words;
/**
 *
 * @author angel
 */
/**
 * La clase El_Ahorcado representa el juego del ahorcado. Utiliza una lista de palabras
 * para seleccionar una palabra aleatoria a adivinar. Los jugadores intentan adivinar la palabra
 * ingresando letras, y se representa visualmente mediante un monigote que va poniendo partes en
 * caso de fallo.
 */
public class El_Ahorcado {
    /**
     * Número máximo de intentos permitidos.
     */
    private static final int MAX_INTENTOS = 6;
    
    /**
     * Palabra a adivinar.
     */
    private String palabra;
    /**
     * Representación oculta de la palabra, con guiones bajos para las letras no adivinadas.
     */
    private String palabraOculta;
     /**
     * Intentos restantes para adivinar la palabra.
     */
    private int intentosRestantes;
      /**
     * Pila que almacena la representación visual del monigote.
     */
    private PilaMonigote pilaMonigote;
    /**
     * Lista de palabras disponibles para el juego.
     */
    private ListaPalabras listaPalabras;
    /**
     * Índice de la palabra actual en la lista.
     */
    private int indicePalabraActual;
     /**
     * Constructor que inicializa una nueva instancia del juego del ahorcado.
     */
    public El_Ahorcado() {
        this.listaPalabras = new ListaPalabras();
        cargarPalabraAleatoria();
        this.intentosRestantes = MAX_INTENTOS;
        this.pilaMonigote = new PilaMonigote(6);
        this.indicePalabraActual = -1;
    }

    /**
     * Carga una palabra aleatoria de la lista de palabras disponibles.
     */
    private void cargarPalabraAleatoria() {
         Words palabraObjeto = listaPalabras.obtenerPalabraAleatoria();
        this.palabra = palabraObjeto.getConcepto();
        this.palabraOculta = "_".repeat(palabra.length());
    }
     /**
     * Muestra el estado actual del juego, incluyendo la palabra oculta, los intentos restantes
     * y la representación visual del monigote.
     */
    private void mostrarEstado() {
        System.out.println("Palabra: " + palabraOculta);
        System.out.println("Intentos restantes: " + intentosRestantes);
        System.out.println("Monigote: \n" + pilaMonigote.obtenerMonigote());
    }
     /**
     * Verifica si una letra ingresada por el jugador está en la palabra a adivinar.
     * Actualiza la palabra oculta y la pila del monigote según corresponda.
     *
     * @param letra Letra ingresada por el jugador.
     */
    private void adivinarLetra(char letra) {
        boolean acierto = false;
        char letraMinuscula = Character.toLowerCase(letra);

        for (int i = 0; i < palabra.length(); i++) {
            char letraPalabra = Character.toLowerCase(palabra.charAt(i));
            if (letraPalabra == letraMinuscula) {
                palabraOculta = palabraOculta.substring(0, i) + letra + palabraOculta.substring(i + 1);
                acierto = true;
            }
        }

        if (!acierto) {
            intentosRestantes--;
            actualizarMonigote();
        }
    }
     /**
     * Actualiza la representación visual del monigote en la pila, dependiendo de los intentos restantes.
     */
    private void actualizarMonigote() {
        switch (intentosRestantes) {
            case 5:
                pilaMonigote.push("___   \n".toCharArray());
                break;
            case 4:
                pilaMonigote.push("   |  \n".toCharArray());
                break;
            case 3:
                pilaMonigote.push("   O   \n".toCharArray());
                break;
            case 2:
                pilaMonigote.push("  /||\\ \n".toCharArray());
                break;
            case 1:
                pilaMonigote.push("   /\\\n".toCharArray());
                break;
            case 0:
                pilaMonigote.push("GAME OVER".toCharArray());
                break;
        }
        System.out.println("Monigote actual:\n" + pilaMonigote.obtenerMonigote());
    }
     /**
     * Inicia el juego del ahorcado. El jugador intenta adivinar la palabra ingresando letras hasta
     * que se queden sin intentos o adivinen la palabra.
     */
    public void jugar() {
        Scanner scanner = new Scanner(System.in);
        while (intentosRestantes > 0 && palabraOculta.contains("_")) {
            mostrarEstado();
            System.out.print("Adivina una letra: ");
            char letra = scanner.next().toLowerCase().charAt(0);
            adivinarLetra(letra);
        }
        mostrarResultado();
    }
     /**
     * Muestra el resultado final del juego, indicando si el jugador ganó o perdió y la palabra correcta.
     */
    private void mostrarResultado() {
        mostrarEstado();
        if (intentosRestantes > 0) {
            System.out.println("¡Ganaste! La palabra es: " + palabra + " - " + definicionDeLaPalabra());
        } else {
            System.out.println("¡Perdiste! La palabra era: " + palabra + " - " + definicionDeLaPalabra());
        }
    }
    /**
     * Obtiene la definición de la palabra adivinada desde el archivo de palabras.
     *
     * @return Definición de la palabra.
     */
    private String definicionDeLaPalabra() {
        try {
            File archivo = new File("glosario.csv");
            BufferedReader lector = new BufferedReader(new FileReader(archivo));

            String linea;
            while ((linea = lector.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length >= 2 && partes[0].equalsIgnoreCase(palabra)) {
                    lector.close();
                    return partes[1].trim();
                }
            }

            lector.close();
        } catch (IOException e) {
            System.err.println("Error al leer el archivo de palabras.");
            System.exit(1);
        }

        return "Definición no disponible";
    }
}
