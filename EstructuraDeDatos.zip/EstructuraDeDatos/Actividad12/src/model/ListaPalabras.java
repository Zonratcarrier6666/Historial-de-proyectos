/*
 Esta clase representa una lista enlazada de palabras (objetos Words).
 Se carga inicialmente desde un archivo CSV ("glosario.csv").
Osea que usa objetos de tipo Words para poder agregarlos mediante un
archivo CSV para poder agregarlos a una lista enlazada.
 */
/* RANDOM 
La clase Random es una clase en el paquete java.util en Java que se utiliza para generar números pseudoaleatorios.
Los números pseudoaleatorios son secuencias de números que parecen ser aleatorios, pero que se generan de acuerdo 
con un algoritmo determinista.
La clase Random proporciona métodos para generar diferentes tipos de datos aleatorios, como números enteros, números
en punto flotante, y otros. Algunos de los métodos más comunes de la clase Random incluyen:
nextInt(): Devuelve un número entero aleatorio.
nextDouble(): Devuelve un número en punto flotante aleatorio entre 0.0 y 1.0.
nextBoolean(): Devuelve un valor booleano aleatorio.
nextLong(): Devuelve un número largo aleatorio.
USO:
Random random = new Random();
random.nextInt();
random.nextDouble();
random.nextBoolean();
random.nextLong();
*/
package model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Random;

/**
 *
 * @author angel
 */
public class ListaPalabras {
    private NodoPalabra inicio;
    //A puntamos el nodo al inicio.
    private int tamanio;
    //tamaño de la lista
    public ListaPalabras() {
        inicio = null;
        tamanio = 0;
        cargarPalabrasDesdeArchivo();
    }
     /*Inicializa la lista como vacía y carga palabras desde un archivo CSV.*/

    private void cargarPalabrasDesdeArchivo() {
        /*Lee el archivo "glosario.csv" y agrega palabras a la lista.*/
        try {
            File archivo = new File("glosario.csv");
            BufferedReader lector = new BufferedReader(new FileReader(archivo));

            lector.readLine(); // Saltar la primera línea
            String linea;
            while ((linea = lector.readLine()) != null) {
                String[] info = linea.split(",");
                agregarPalabra(new Words(info[0], info[1])); 
                // Agregar palabra a la lista como un objeto "Words"
            }
            lector.close();
        } catch (IOException e) {
            System.err.println("Error al leer el archivo de palabras.");
            System.exit(1);
        }
    }
     /**
     * Verifica si la lista de palabras está vacía.
     * True si la lista está vacía, false de lo contrario.
     */
    public boolean esVacia() {
        return inicio == null;
    }
     /*Obtiene el tamaio de la lista*/
    public int getTamanio() {
        return tamanio;
    }
     /**
     * Agrega una palabra a la lista.
     * palabra Objeto Words que representa la palabra y su definición.
     */
    public void agregarPalabra(Words palabra) {
        NodoPalabra nuevo = new NodoPalabra(palabra);
        if (esVacia()) {
            inicio = nuevo;
        } else {
            NodoPalabra aux = inicio;
            while (aux.getSiguiente() != null) {
                aux = aux.getSiguiente();
            }
            aux.setSiguiente(nuevo);
        }
        tamanio++;
    }
     /**
     * Obtiene una palabra aleatoria de la lista.
     * Palabra aleatoria como objeto Words.
     */
    public Words obtenerPalabraAleatoria() {
        Random random = new Random();
        int indiceAleatorio = random.nextInt(tamanio);
        try {
            return getPalabraPorPosicion(indiceAleatorio);
        } catch (Exception e) {
            System.err.println("Error al obtener palabra aleatoria.");
            return null;  // Manejar el error según sea necesario
        }
    }
      /**
     * Obtiene una palabra en una posición específica de la lista.
     * @param posicion Posición de la palabra en la lista.
     * @return Palabra en la posición especificada como objeto Words.
     * @throws Exception Si la posición no es válida.
     */
    public Words getPalabraPorPosicion(int posicion) throws Exception {
        if (posicion >= 0 && posicion < tamanio) {
            NodoPalabra aux = inicio;
            for (int i = 0; i < posicion; i++) {
                aux = aux.getSiguiente();
            }
            return aux.getPalabra();
        } else {
            throw new Exception("Posición inexistente en la lista.");
        }
    }
     /**
     * Clase interna NodoPalabra
     * Representa un nodo en la lista enlazada que contiene una palabra.
     */
    private class NodoPalabra {
        private Words palabra; //palabra que esta almacenada dentro del nodo
        private NodoPalabra siguiente;//Referenciamos al siguiente nodo
        /**
         * Constructor de la clase NodoPalabra.
         * @param palabra Objeto Words que representa la palabra y su definición.
         */
        public NodoPalabra(Words palabra) {
            this.palabra = palabra;
            this.siguiente = null;
        }

        public Words getPalabra() {
            return palabra;
        }

        public NodoPalabra getSiguiente() {
            return siguiente;
        }

        public void setSiguiente(NodoPalabra siguiente) {
            this.siguiente = siguiente;
        }
    }
}
