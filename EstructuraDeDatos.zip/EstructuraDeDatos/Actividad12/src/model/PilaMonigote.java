package model;

/**
 *
 * @author angel
 */
/**
 * La clase PilaMonigote representa una pila que almacena elementos de tipo char[].
 * Se utiliza en el juego del ahorcado para gestionar la representación del monigote.
 * La pila tiene un tamaño fijo y permite realizar operaciones como push y pop.
 */
public class PilaMonigote {
     /**
     * Arreglo bidimensional que almacena los elementos de la pila.
     */
    private char[][] elementos;
     /**
     * Tamaño máximo de la pila.
     */
    private int tamano; /**
     * Índice del tope de la pila.
     */
    private int tope;
    /**
     * Constructor que inicializa una nueva instancia de la clase PilaMonigote con el tamaño especificado.
     *
     * @param tamano Tamaño máximo de la pila.
     */
    public PilaMonigote(int tamano) {
        this.tamano = tamano;
        this.elementos = new char[tamano][];
        this.tope = -1;
    }
      /**
     * Agrega un elemento a la pila (operación push).
     *
     * @param elemento Elemento de tipo char[] que se va a agregar a la pila.
     */
    public void push(char[] elemento) {
        if (tope < tamano - 1) {
            tope++;
            elementos[tope] = elemento;
        } else {
            System.out.println("La pila está llena.");
        }
    }
     /**
     * Elimina el elemento en el tope de la pila (operación pop).
     */
    public void pop() {
        if (tope >= 0) {
            tope--;
        } else {
            System.out.println("La pila está vacía.");
        }
    }
     /**
     * Obtiene la representación del monigote concatenando los elementos de la pila.
     *
     * @return Representación del monigote como un String.
     */
    public String obtenerMonigote() {
        StringBuilder monigote = new StringBuilder();
        for (int i = 0; i <= tope; i++) {
            monigote.append(elementos[i]);
        }
        return monigote.toString();
    }
}
