package modelo;

/**
 *
 * @author angel
 */
public class Pila {
    private int[] pila;  // Arreglo que actúa como la estructura de la pila
    private int top;     // Índice del elemento en la parte superior de la pila
    private int size;    // Tamaño actual de la pila

    public Pila(int capacidad) {
        pila = new int[capacidad];  // Inicializa el arreglo con la capacidad especificada
        top = -1;                 // Inicializa el índice de la parte superior como -1 (pila vacía)
        size = 0;                // Inicializa el tamaño como 0
    }
    // Método para añadir un elemento en la parte superior de la pila
    public void push(int elemento) {
        if (top < pila.length - 1) {  // Verifica si la pila no está llena
            pila[++top] = elemento;   // Incrementa el índice de la parte superior y agrega el elemento
            size++;                  // Incrementa el tamaño de la pila
        } else {
            System.out.println("La pila está llena. No se puede agregar más elementos.");
        }
    }
    // Método para extraer y eliminar el elemento de la parte superior de la pila
    public int pop() {
        if (isEmpty()) {
            throw new IllegalStateException("La pila está vacía");
        }
        size--;              // Decrementa el tamaño de la pila
        return pila[top--];  // Devuelve el elemento en la parte superior y disminuye el índice
    }
    // Método para verificar si la pila está vacía
    public boolean isEmpty() {
        return top == -1;  // La pila está vacía si el índice de la parte superior es -1
    }
    // Método para ver el elemento de la parte superior de la pila sin eliminarlo
    public int peek() {
        if (isEmpty()) {
            throw new IllegalStateException("La pila está vacía");
        }
        return pila[top];  // Devuelve el elemento en la parte superior sin cambiar el índice
    }
    // Método para obtener el tamaño de la pila
    public int size() {
        return size;  // Devuelve el tamaño actual de la pila
    }
}