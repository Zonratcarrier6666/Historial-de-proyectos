/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package vista;

import java.util.Scanner;
import modelo.Pila;

/**
 *
 * @author angel
 */
public class ViewPila {

    public static void main(String[] args) {
        Pila pila = new Pila(5); // Crear una pila con capacidad para 5 elementos
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nOperaciones de la pila:");
            System.out.println("1. Push (Añadir elemento)");
            System.out.println("2. Pop (Extraer elemento)");
            System.out.println("3. Peek (Ver elemento en la parte superior)");
            System.out.println("4. Tamaño de la pila");
            System.out.println("5. Salir");
            System.out.print("Elija una operación (1-5): ");

            int opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el elemento a añadir: ");
                    int elemento = scanner.nextInt();
                    pila.push(elemento);
                    break;
                case 2:
                    try {
                    int elementoExtraido = pila.pop();
                    System.out.println("Elemento extraído: " + elementoExtraido);
                } catch (IllegalStateException e) {
                    System.out.println("La pila está vacía. No se puede extraer.");
                }
                break;
                case 3:
                    try {
                    int elementoSuperior = pila.peek();
                    System.out.println("Elemento en la parte superior: " + elementoSuperior);
                } catch (IllegalStateException e) {
                    System.out.println("La pila está vacía. No hay elementos en la parte superior.");
                }
                break;
                case 4:
                    System.out.println("Tamaño de la pila: " + pila.size());
                    break;
                case 5:
                    System.out.println("Saliendo del programa.");
                    System.exit(0);
                default:
                    System.out.println("Opción no válida. Por favor, elija una opción válida.");
            }
        }
    }
}
