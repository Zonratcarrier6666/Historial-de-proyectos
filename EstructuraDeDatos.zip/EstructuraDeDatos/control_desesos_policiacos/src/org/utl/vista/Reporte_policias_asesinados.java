package org.utl.vista;

import java.io.IOException;
import java.util.Scanner;
import javax.swing.JOptionPane;
import org.utl.controlador.Controlador_Police;
import org.utl.data.Data_police;
import org.utl.model.Police;

public class Reporte_policias_asesinados {

    public static void generarMenu() throws IOException {
        Scanner leer = new Scanner(System.in);
        Data_police dp = new Data_police();
        Controlador_Police cp = new Controlador_Police();

        Police[] polis = dp.getAll();

        Police[] polHayados = null;
        String respuesta = JOptionPane.showInputDialog(""
                + "Por cuál campo deseas hacer la búsqueda: \n"
                + "Edad \n"
                + "Por rango de edades, escribe rango \n"
                + "Día");

        switch (respuesta) {
            case "edad":
                int edad = Integer.parseInt(JOptionPane.showInputDialog("De que edad quieres buscar a los policias"));
                polHayados = cp.buscarXEdad(polis, edad);

                System.out.println("++++ Estos son los policias con edad de " + edad + "++++");
                for (Police d : polHayados) {
                    System.out.println(d);
                }
                break;
            case "rango":
                int edadMenor = Integer.parseInt(JOptionPane.showInputDialog("Cual es la edad del limite inferior "));
                int edadMayor = Integer.parseInt(JOptionPane.showInputDialog("Cual es la edad del limite superior "));
                polHayados = cp.buscarXRangoEdad(polis, edadMenor, edadMayor);

                System.out.println("++++ Estos son los policias con edad entre" + edadMenor + " y " + edadMayor + "  ++++");
                for (Police d : polHayados) {
                    System.out.println(d);
                }
                break;
            case "dia":
                int day = 0;
                // Dentro del caso "Día" en el método generarMenu
                Police[] policiaMuertos = cp.buscarXDia(day, polHayados);

                if (policiaMuertos.length > 0) {
                    System.out.println("Bajas encontradas:");
                    for (Police policia : policiaMuertos) {
                        System.out.println(policia);
                    }
                } else {
                    System.out.println("Bajas no encontradas.");
                }

                break;
        }
    }

    public static void main(String[] args) throws IOException {
        generarMenu();
    }
}
