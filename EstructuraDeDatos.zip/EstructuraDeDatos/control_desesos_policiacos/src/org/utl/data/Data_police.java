/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.utl.data;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import org.utl.model.Police;

/**
 *
 * @author Carmen
 */
public class Data_police {
    public Police[] getAll() throws FileNotFoundException, IOException{
       String strng;
       int i =0;
       String[] info = new String[10];
       Police [] policias = new Police[463];
       File doc = new File("police_killings.csv");

       BufferedReader obj = new BufferedReader(new FileReader(doc));
       obj.readLine();
       while ((strng = obj.readLine()) != null){
            info =strng.split(",");
            Police poli = new Police(info[0],
                                     Integer.parseInt(info[1]),
                                     info[2],
                                     info[3],
                                     info[4],
                                     Integer.parseInt(info[5]),
                                     Integer.parseInt(info[6]),
                                     info[7],
                                     info[8],
                                     info[9]
            );
            policias[i]=poli;
            i++;
       }
       return policias;
    }
}