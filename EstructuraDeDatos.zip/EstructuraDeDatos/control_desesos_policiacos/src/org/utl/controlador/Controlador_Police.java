package org.utl.controlador;

import org.utl.model.Police;

/**
 *
 * @author Carmen
 */
public class Controlador_Police {

    public Police[] buscarXEdad(Police[] policias, int datoBusqueda) {
        Police[] poliEncontrados = null;
        int c = 0;
        int i = 0;
        for (Police p : policias) {
            if (p.getAge() == datoBusqueda) {
                c++;
            }
        }
        poliEncontrados = new Police[c];

        for (Police a : policias) {
            if (a.getAge() == datoBusqueda) {
                poliEncontrados[i] = a;
                i++;
            }
        }
        return poliEncontrados;
    }

    public Police[] buscarXRangoEdad(Police[] polisFuente, int edadMenor, int edadMayor) {
        Police[] poliEncontrados = null;
        int c = 0;
        int i = 0;
        for (Police p : polisFuente) {
            if (p.getAge() >= edadMenor && p.getAge() <= edadMayor) {
                c++;
            }
        }
        poliEncontrados = new Police[c];

        for (Police a : polisFuente) {
            if (a.getAge() >= edadMenor && a.getAge() <= edadMayor) {
                poliEncontrados[i] = a;
                i++;
            }
        }
        return poliEncontrados;
    }

    public Police[] buscarXDia(int day, Police[] poliEncontrados) {
        int izquierda = 0;
        int derecha = poliEncontrados.length - 1;

        int count = 0; // Contador para rastrear el número de coincidencias
        Police[] coincidencias = new Police[poliEncontrados.length]; // Arreglo para almacenar las coincidencias

        while (izquierda <= derecha) {
            int medio = izquierda + (derecha - izquierda) / 2;
            Police policia = poliEncontrados[medio];

            if (policia != null) {
                int dayMedio = policia.getDay();

                if (dayMedio == day) {
                    // Se encontró una coincidencia, se agrega al arreglo de coincidencias
                    coincidencias[count] = policia;
                    count++;
                }

                if (dayMedio < day) {
                    izquierda = medio + 1;
                } else {
                    derecha = medio - 1;
                }
            }
        }

        // Se crea un nuevo arreglo para almacenar solo las coincidencias sin valores nulos
        Police[] resultados = new Police[count];
        System.arraycopy(coincidencias, 0, resultados, 0, count);

        return resultados; // Se devuelve el arreglo de coincidencias
    }

}
