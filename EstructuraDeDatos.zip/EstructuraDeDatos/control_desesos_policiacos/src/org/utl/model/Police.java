/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.utl.model;

/**
 *
 * @author Carmen
 */
public class Police {
    /**
     * @return the name
     */
    public String getName() {
        return name;
    }
    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }
    /**
     * @return the age
     */
    public int getAge() {
        return age;
    }
    /**
     * @param age the age to set
     */
    public void setAge(int age) {
        this.age = age;
    }
    /**
     * @return the gender
     */
    public String getGender() {
        return gender;
    }
    /**
     * @param gender the gender to set
     */
    public void setGender(String gender) {
        this.gender = gender;
    }
    /**
     * @return the raceethnicity
     */
    public String getRaceethnicity() {
        return raceethnicity;
    }
    /**
     * @param raceethnicity the raceethnicity to set
     */
    public void setRaceethnicity(String raceethnicity) {
        this.raceethnicity = raceethnicity;
    }

    /**
     * @return the month
     */
    public String getMonth() {
        return month;
    }

    /**
     * @param month the month to set
     */
    public void setMonth(String month) {
        this.month = month;
    }

    /**
     * @return the day
     */
    public int getDay() {
        return day;
    }

    /**
     * @param day the day to set
     */
    public void setDay(int day) {
        this.day = day;
    }

    /**
     * @return the year
     */
    public int getYear() {
        return year;
    }

    /**
     * @param year the year to set
     */
    public void setYear(int year) {
        this.year = year;
    }

    /**
     * @return the streetaddress
     */
    public String getStreetaddress() {
        return streetaddress;
    }

    /**
     * @param streetaddress the streetaddress to set
     */
    public void setStreetaddress(String streetaddress) {
        this.streetaddress = streetaddress;
    }

    /**
     * @return the city
     */
    public String getCity() {
        return city;
    }

    /**
     * @param city the city to set
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * @return the state
     */
    public String getState() {
        return state;
    }

    /**
     * @param state the state to set
     */
    public void setState(String state) {
        this.state = state;
    }
    private String name; 
    private int	age; 
    private String gender;
    private String raceethnicity;
    private String month;
    private int day;
    private int	year;	
    private String streetaddress; 	
    private String city; 
    private String	state;
public Police( String name, 
                int age, 
                String gender,
                String raceethnicity,
                String month,
                int day,
                int year,	
                String streetaddress, 	
                String city, 
                String	state){
    this.name=name; 
    this.age=age; 
    this.gender=gender;
    this.raceethnicity=raceethnicity;
    this.month=month;
    this.day=day;
    this.year=year;	
    this.streetaddress=streetaddress; 	
    this.city=city; 
    this.state=state;
}

@Override
public String toString(){
return age+"\t"+name+"\t"+gender+"\t"+raceethnicity+"\t"+ day+"/"+month+"/"+year;
}
}
