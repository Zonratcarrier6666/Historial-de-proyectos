/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package view;

import controller.ListaDoblementeCircular;
import controller.NodoDobleCircular;
import java.util.Scanner;

/**
 *
 * @author angel
 */
public class menu {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);
        ListaDoblementeCircular lista = new ListaDoblementeCircular();

        int opcion;
        do {
            System.out.println("\nMenú de Operaciones:");
            System.out.println("1. Insertar al inicio");
            System.out.println("2. Insertar al final");
            System.out.println("3. Insertar por valor (referencia)");
            System.out.println("4. Insertar por posición");
            System.out.println("5. Buscar valor");
            System.out.println("6. Editar por valor (referencia)");
            System.out.println("7. Editar por posición");
            System.out.println("8. Eliminar por valor (referencia)");
            System.out.println("9. Eliminar por posición");
            System.out.println("10. Mostrar lista");
            System.out.println("11. Mostrar lista inversa");
            System.out.println("12. Eliminar lista");
            System.out.println("13. Salir");

            System.out.print("Elija una opción: ");
            opcion = sc.nextInt();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el valor a insertar al inicio: ");
                    int valorInicio = sc.nextInt();
                    NodoDobleCircular nuevoNodoInicio = new NodoDobleCircular(valorInicio);
                    lista.insertarInicio(nuevoNodoInicio);
                    break;

                case 2:
                    System.out.print("Ingrese el valor a insertar al final: ");
                    int valorFinal = sc.nextInt();
                    NodoDobleCircular nuevoNodoFinal = new NodoDobleCircular(valorFinal);
                    lista.insertarFinal(nuevoNodoFinal);
                    break;

                case 3:
                    System.out.print("Ingrese el valor de referencia: ");
                    int valorReferencia = sc.nextInt();
                    System.out.print("Ingrese el valor nuevo: ");
                    int valorNuevo = sc.nextInt();
                    NodoDobleCircular nuevoNodoPorValor = new NodoDobleCircular(valorNuevo);
                    lista.insertarPorValor(valorReferencia, nuevoNodoPorValor);
                    break;

                case 4:
                    System.out.print("Ingrese el valor a insertar: ");
                    int valorPosicion = sc.nextInt();
                    System.out.print("Ingrese la posición: ");
                    int posicion = sc.nextInt();
                    NodoDobleCircular nuevoNodoPosicion = new NodoDobleCircular(valorPosicion);
                    lista.insertarPorPosicion(nuevoNodoPosicion, posicion);
                    break;

                case 5:
                    System.out.print("Ingrese el valor a buscar: ");
                    int valorBuscar = sc.nextInt();
                    boolean encontrado = lista.buscar(valorBuscar);
                    if (encontrado) {
                        System.out.println("El valor " + valorBuscar + " se encuentra en la lista.");
                    } else {
                        System.out.println("El valor " + valorBuscar + " no se encuentra en la lista.");
                    }
                    break;

                case 6:
                    System.out.print("Ingrese el valor de referencia: ");
                    int valorRefEditar = sc.nextInt();
                    System.out.print("Ingrese el valor nuevo: ");
                    int valorNuevoEditar = sc.nextInt();
                    lista.editarPorValor(valorRefEditar, valorNuevoEditar);
                    break;

                case 7:
                    System.out.print("Ingrese la posición: ");
                    int posicionEditar = sc.nextInt();
                    System.out.print("Ingrese el valor nuevo: ");
                    int valorNuevoPosicion = sc.nextInt();
                    lista.editarPorPosicion(valorNuevoPosicion, posicionEditar);
                    break;

                case 8:
                    System.out.print("Ingrese el valor de referencia a eliminar: ");
                    int valorEliminarRef = sc.nextInt();
                    lista.eliminarPorValor(valorEliminarRef);
                    break;

                case 9:
                    System.out.print("Ingrese la posición a eliminar: ");
                    int posicionEliminar = sc.nextInt();
                    lista.eliminarPorPosicion(posicionEliminar);
                    break;

                case 10:
                    System.out.println("Lista actual:");
                    lista.mostrarLista();
                    break;

                case 11:
                    System.out.println("Lista inversa:");
                    lista.mostrarListaAlReves();
                    break;

                case 12:
                    lista.eliminarLista();
                    System.out.println("Lista eliminada.");
                    break;

                case 13:
                    System.out.println("Saliendo del programa.");
                    break;

                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
                    break;
            }
        } while (opcion != 13);
    }
}
