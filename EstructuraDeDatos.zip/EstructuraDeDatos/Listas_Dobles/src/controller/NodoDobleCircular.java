/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

/**
 *
 * @author angel
 */
public class NodoDobleCircular {
     int valor;
    NodoDobleCircular siguiente;
    NodoDobleCircular anterior;

    public NodoDobleCircular(int valor) {
        this.valor = valor;
        this.siguiente = null;
        this.anterior = null;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public NodoDobleCircular getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoDobleCircular siguiente) {
        this.siguiente = siguiente;
    }

    public NodoDobleCircular getAnterior() {
        return anterior;
    }

    public void setAnterior(NodoDobleCircular anterior) {
        this.anterior = anterior;
    }

    @Override
    public String toString() {
        return "NodoDobleCircular{" + "valor=" + valor + ", siguiente=" + siguiente + ", anterior=" + anterior + '}';
    }
    
}
