package controller;

/**
 *
 * @author angel
 */
public class ListaDoblementeCircular {

    private NodoDobleCircular ultimo;
    private NodoDobleCircular inicio;
    private int tamanio;

    public ListaDoblementeCircular() {
        ultimo = null;
        inicio = null;
        tamanio = 0;
    }

    public boolean estaVacia() {
        return inicio == null;
    }

    public void insertarInicio(NodoDobleCircular nuevoNodo) {
        if (estaVacia()) {
            inicio = nuevoNodo;
            ultimo = nuevoNodo;
            inicio.setSiguiente(inicio);
            inicio.setSiguiente(ultimo);
        } else {
            nuevoNodo.setSiguiente(inicio);
            nuevoNodo.setAnterior(ultimo);
            inicio.setAnterior(nuevoNodo);
            inicio = nuevoNodo;
            ultimo.setSiguiente(inicio);
        }
        tamanio++;
    }
//Insertar ala final 

    public void insertarFinal(NodoDobleCircular nuevoNodo) {
        if (estaVacia()) {
            inicio = nuevoNodo;
            inicio.setSiguiente(inicio);
            inicio.setAnterior(inicio);
            ultimo = inicio;
        } else {
            nuevoNodo.setSiguiente(ultimo);
            nuevoNodo.setAnterior(inicio);
            ultimo.setSiguiente(nuevoNodo);
            ultimo = nuevoNodo;
            inicio.setAnterior(ultimo);
        }
        tamanio++;
    }

    public void mostrarListaAlReves() {
        if (estaVacia()) {
            System.out.println("La lista está vacía.");
        } else {
            NodoDobleCircular actual = ultimo;
            do {
                System.out.print(actual.getValor() + " <-> ");
                actual = actual.getAnterior();
            } while (actual != ultimo);
            System.out.println("Fin");
        }
    }

    public void insertarPorValor(int valorReferencia, NodoDobleCircular nuevoNodo) {
        if (!estaVacia()) {
            NodoDobleCircular actual = inicio;
            do {
                if (actual.getValor() == valorReferencia) {
                    nuevoNodo.setSiguiente(actual.getSiguiente());
                    nuevoNodo.setAnterior(actual);
                    actual.getSiguiente().setAnterior(nuevoNodo);
                    actual.setSiguiente(nuevoNodo);
                    if (actual == inicio.getAnterior()) {
                        inicio.setAnterior(nuevoNodo);
                    }
                    tamanio++;
                }
                actual = actual.getSiguiente();
            } while (actual != inicio);
        }
    }
    public void insertarPorPosicion(NodoDobleCircular nuevoNodo, int posicion) {
        if (posicion < 0) {
            return;
        }
        if (posicion == 0 || estaVacia()) {
            insertarInicio(nuevoNodo);
        } else {
            NodoDobleCircular actual = inicio;
            int contador = 0;
            while (contador < posicion - 1 && actual.getSiguiente() != inicio) {
                actual = actual.getSiguiente();
                contador++;
            }
            nuevoNodo.setSiguiente(actual.getSiguiente());
            nuevoNodo.setAnterior(actual);
            actual.getSiguiente().setAnterior(nuevoNodo);
            actual.setSiguiente(nuevoNodo);
            if (actual == inicio.getAnterior()) {
                inicio.setAnterior(nuevoNodo);
            }
            tamanio++;
        }
    }
    public boolean buscar(int valor) {
        if (estaVacia()) {
            return false;
        }
        NodoDobleCircular actual = inicio;
        do {
            if (actual.getValor() == valor) {
                return true;
            }
            actual = actual.getSiguiente();
        } while (actual != inicio);
        return false;
    }

    public void editarPorValor(int valorReferencia, int valorNuevo) {
        if (!estaVacia()) {
            NodoDobleCircular actual = inicio;
            do {
                if (actual.getValor() == valorReferencia) {
                    actual.setValor(valorNuevo);
                }
                actual = actual.getSiguiente();
            } while (actual != inicio);
        }
    }

    public void editarPorPosicion(int valorNuevo, int posicion) {
        if (estaVacia() || posicion < 0) {
            return;
        }
        if (posicion == 0) {
            inicio.setValor(valorNuevo);
        } else {
            NodoDobleCircular actual = inicio;
            int contador = 0;
            while (contador < posicion && actual.getSiguiente() != inicio) {
                actual = actual.getSiguiente();
                contador++;
            }
            actual.setValor(valorNuevo);
        }
    }

    public void eliminarPorValor(int valor) {
        if (!estaVacia()) {
            NodoDobleCircular actual = inicio;
            do {
                if (actual.getValor() == valor) {
                    actual.getAnterior().setSiguiente(actual.getSiguiente());
                    actual.getSiguiente().setAnterior(actual.getAnterior());
                    if (actual == inicio) {
                        inicio = actual.getSiguiente();
                    }
                    tamanio--;
                }
                actual = actual.getSiguiente();
            } while (actual != inicio);
        }
    }

    public void eliminarPorPosicion(int posicion) {
        if (estaVacia() || posicion < 0) {
            return;
        }
        if (posicion == 0) {
            inicio.getAnterior().setSiguiente(inicio.getSiguiente());
            inicio.getSiguiente().setAnterior(inicio.getAnterior());
            inicio = inicio.getSiguiente();
        } else {
            NodoDobleCircular actual = inicio;
            int contador = 0;
            while (contador < posicion && actual.getSiguiente() != inicio) {
                actual = actual.getSiguiente();
                contador++;
            }
            actual.getAnterior().setSiguiente(actual.getSiguiente());
            actual.getSiguiente().setAnterior(actual.getAnterior());
            if (actual == inicio) {
                inicio = actual.getSiguiente();
            }
            tamanio--;
        }
    }

    public void mostrarLista() {
        if (estaVacia()) {
            System.out.println("La lista está vacía.");
        } else {
            NodoDobleCircular actual = inicio;
            do {
                System.out.print(actual.getValor() + " <-> ");
                actual = actual.getSiguiente();
            } while (actual != inicio);
            System.out.println("Fin");
        }
    }

    public void mostrarListaInvertida() {
        if (estaVacia()) {
            System.out.println("La lista está vacía.");
        } else {
            NodoDobleCircular actual = ultimo;
            do {
                System.out.print(actual.getValor() + " <-> ");
                actual = actual.getSiguiente();
            } while (actual != ultimo);
            System.out.println("Fin");
        }
    }

    public void eliminarLista() {
        inicio = null;
        tamanio = 0;
    }
}
