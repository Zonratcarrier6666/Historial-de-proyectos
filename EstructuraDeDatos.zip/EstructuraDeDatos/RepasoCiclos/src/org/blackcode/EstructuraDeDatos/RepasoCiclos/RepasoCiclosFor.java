package org.blackcode.EstructuraDeDatos.RepasoCiclos;

import java.util.Scanner;

public class RepasoCiclosFor {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese la cantidad de números: ");
        int cantidadNumeros = scanner.nextInt();

        int sumaPares = 0;
        int cantidadPares = 0;

        for (int i = 1; i <= cantidadNumeros; i++) {
            System.out.print("Ingrese el número " + i + ": ");
            int numero = scanner.nextInt();

            if (numero % 2 == 0) {
                sumaPares += numero;  // Agrega el número par a la suma
                cantidadPares++;     // Incrementa la cantidad de números pares
            }
        }

        scanner.close();

        if (cantidadPares > 0) {
            double promedioPares = (double) sumaPares / cantidadPares;
            System.out.println("Suma de números pares: " + sumaPares);
            System.out.println("Promedio de números pares: " + promedioPares);
        } else {
            System.out.println("No se ingresaron números pares.");
        }
    }
}

