package org.blackcode.EstructuraDeDatos.TiposDeDatosAbstractos;

public class TiposDeDatosAbstractos {

    public static void main(String[] args) {
        ///IIIIIIII/NN////NN//TTTTTTTT//EEEEEEE//GGGGGGG/EEEEEEE//RRRRRRR///////
        //////II////NNNN//NN/////TT/////EE//////GG///////EE///////RR////RR//////
        //////II////NN/NN/NN/////TT/////EEEEEE//GG///GGG/EEEEEEE//RR////RR//////
        //////II////NN//NNNN/////TT/////EE//////GG////GG/EE///////RR/RRRR///////
        ///IIIIIIII/NN///NNN/////TT/////EEEEEEE//GGGGGG//EEEEEEE//RR////RR//////
//    INTEGER equals SIRVE PARA COMPARAR OBJETOS CON VALOR NUMERICO Y REGRESA UN VALOR DE TIPO BOOLEANO
//    Creamos dos objetos Integer con el mismo valor.
        Integer numero1 = 17;
        Integer numero2 = 42;
        String res1 = "";
        String res2 = "";

        // Creamos un objeto Integer con un valor diferente
        Integer numero3 = 17;

        // Usamos el método equals para comparar los objetos
        boolean compararNumero1yNumero2 = numero1.equals(numero2);
        boolean compararNumero1yNumero3 = numero1.equals(numero3);
        if (compararNumero1yNumero2 == true) {
            res1 = "SON IGUALES";
        }
        if (compararNumero1yNumero2 == false) {
            res1 = "NO SON IGUALES";
        }
        if (compararNumero1yNumero3 == false) {
            res2 = "NO SON IGUALES";
        }
        if (compararNumero1yNumero3 == true) {
            res2 = "SON IGUALES";
        }
        System.out.println("¿El Numero1 es igual al Numero2? " + res1);
        System.out.println("¿El Numero1 es igual al Numero3? " + res2);
//        INTEGER Value Es para tomar el valor entero de una variable
        Integer x = (15), y = (9);
        int z = x.intValue() + y.intValue();
        int result = z;
        System.out.println(z);
//        INTEGER hasCode sirve para comparar objetos de una forma más rápida en estructuras Hash ya que únicamente
//        nos devuelve un número entero
        // Crear dos objetos Integer con el mismo valor
        Integer nume1 = new Integer(42);
        Integer nume2 = new Integer(42);

        // Obtener el código hash de los objetos Integer
        int hashCode1 = numero1.hashCode();
        int hashCode2 = numero2.hashCode();

        // Mostrar los códigos hash
        System.out.println("hashCode1: " + hashCode1);
        System.out.println("hashCode2: " + hashCode2);

        // Verificar la igualdad de los objetos basados en sus códigos hash
        boolean sonIguales = (hashCode1 == hashCode2);

        // Mostrar el resultado de la comparación de igualdad
        System.out.println("¿numero1 es igual a numero2? " + sonIguales);
//        INTEGER toString simplemente convierte el valor numérico del objeto en una representación de 
//        cadena de caracteres, lo que permite su uso en operaciones de cadena y visualización en la interfaz//
//        de usuario.//
        // Crear un objeto Integer //
        Integer numero = 20001;

        // Utilizar el método toString para convertirlo a una cadena
        String numeroStr = numero.toString();

        // Mostrar la representación de cadena de caracteres
        System.out.println("Número como cadena de caracteres: " + numeroStr);

        // Realizar operaciones de cadena con la representación
        String mensaje = "El número es: " + numeroStr;
        System.out.println(mensaje);
        ////////////////////fffffff/ll///////oooooooo////aa///tttttttttttt//////
        ////////////////////ff//////ll//////oo//////oo//aa/aa/////tt////////////
        ////////////////////fffffff/ll//////oo//////oo/aa///aa////tt////////////
        ////////////////////ff//////ll//////oo//////oo/aaaaaaa////tt////////////
        ////////////////////ff//////llllllll/oooooooo//aa///aa////tt////////////
//        FLOAT compare. Este método es el usado para comparar dos objetos y decidir cuando uno es mayor que otro//
//        y cuando es igual el valor es 0 //
        Integer n1 = 42;
        Integer n2 = 42;

        int resultado = Integer.compare(n1, n2);

        if (resultado < 0) {
            System.out.println("numero 1 es menor que numero 2 ");
        } else if (resultado > 0) {
            System.out.println("numero 1 es mayor que numero 2 ");
        } else {
            System.out.println("numero 1 es igual a numero 2 ");
        }
//        FLOAT equals SIRVE PARA COMPARAR OBJETOS CON VALOR NUMERICO (DECIMAL) Y REGRESA UN VALOR DE TIPO BOOLEANO//
//        Crear dos objetos Float con el mismo valor
        Float numeber1 = 3.14f;
        Float numeber2 = 3.14f;
        String answ1 = "";
        String answ2 = "";

        // Crear un tercer objeto Float con un valor diferente
        Float number3 = 2.71f;

        // Usar el método equals para comparar los objetos
        boolean sonIguales1y2 = numeber1.equals(numeber2);
        boolean sonIguales1y3 = numeber1.equals(number3);
        if (sonIguales1y2 == true) {
            answ1 = "SON IGUALES";
        }
        if (sonIguales1y2 == false) {
            answ1 = "NO SON IGUALES";
        }
        if (sonIguales1y3 == false) {
            answ2 = "NO SON IGUALES";
        }
        if (sonIguales1y3 == true) {
            answ2 = "SON IGUALES";
        }
        System.out.println("¿El Numero1 es igual al Numero2? " + answ1);
        System.out.println("¿El Numero1 es igual al Numero3? " + answ2);
//        FLOAT max es para comparar y elegir el valor con mayor valor.
        float num1 = 3.14f;
        float num2 = 2.71f;

        // Usar Math.max para encontrar el valor máximo
        float maximo = Math.max(num1, num2);

        // Mostrar el resultado
        System.out.println("El valor máximo entre " + num1 + " y " + num2 + " es: " + maximo);

//        FLOAT min es para comparar y elegir el valor con menor valor
        float minimo = Math.min(num1, num2);

        // Mostrar el resultado
        System.out.println("El valor minimo entre " + num1 + " y " + num2 + " es: " + minimo);
        ////////CCCCC/HH///HH//////AA///RRRRRR//////////////
        //////CC//////HH///HH///AA///AA/RR///R//////////////
        //////CC//////HHHHHHH///AA///AA/RRRRR///////////////
        //////CC//////HH///HH///AAAAAAA/RR//RR//////////////
        ////////CCCCC/HH///HH///AA///AA/RR///RR/////////////

//        CHARACTR charCount es para contar las los carcateres
        char caracter1 = 'A';
        char caracter2 = 0;

        // Verificar si un carácter es una letra
        int esLetra1 = Character.charCount(caracter1);
        int esLetra2 = Character.charCount(caracter2);

        // Mostrar los resultados
        System.out.println("¿caracter1 es una letra? " + esLetra1);
        System.out.println("¿caracter2 es una letra? " + esLetra2);

//        CHARACTER compare compara los valores inicode de los valores.
        char char1 = 'A';
        char char2 = 'B';

        // Comparar caracteres alfabéticamente por sus valores Unicode
        int comparacion = Character.compare(char1, char2);

        if (comparacion < 0) {
            System.out.println(char1 + " es menor que " + char2);
        } else if (comparacion > 0) {
            System.out.println(char1 + " es mayor que " + char2);
        } else {
            System.out.println(char1 + " es igual a " + char2);
        }

//        Character equals 
        Character caracter11 = 'A';
        Character caracter22 = 'A';
        // Crear un tercer objeto Character con un valor diferente
        Character caracter33 = 'B';

        // Usar el método equals para comparar los objetos
        boolean sonIguales11y22 = caracter11.equals(caracter22);
        boolean sonIguales11y33 = caracter11.equals(caracter33);

        // Mostrar los resultados
        System.out.println("¿caracter11 es igual a caracter22? " + sonIguales11y22);
        System.out.println("¿caracter11 es igual a caracter33? " + sonIguales11y33);

//        CHARACTER toUpperCase es par atransformar caracteres en en letreas mayusculas.
        char caracterMin = 'a';

        // Utilizar el método toUpperCase para convertir a mayúscula
        char caracterMay = Character.toUpperCase(caracterMin);

        // Mostrar el resultado
        System.out.println("Caracter en minúscula: " + caracterMin);
        System.out.println("Caracter en mayúscula: " + caracterMay);
        ///SSSSSS//TTTTTTTT//RRRRRR////IIIIIII//NN////NN////GGGGGGG/////////////
        //SS///////TTTTTTTT//RR////RR/////II////NNNN//NN///GG////GG/////////////
        //SSSSSS//////TT/////RR////RR/////II////NN/NN/NN///GG///////////////////
        ///////SS/////TT/////RRRRRR///////II////NN//NNNN///GG/////GG////////////
        ///////SS/////TT/////RR////RR/////II////NN///NNN///GG/////GG////////////
        //SSSSS///////TT/////RR////RR//IIIIIIII/NN////NN/////GGGGGG/////////////

//        STRING compareToIgnoreCase sirve para ignorar si son mayusculas o si son minusculas
        String cadena1 = "México";
        String cadena2 = "MÉXICO";

        // Comparar las cadenas ignorando mayúsculas y minúsculas
        int comparacionString = cadena1.compareToIgnoreCase(cadena2);

        // Mostrar el resultado de la comparación
        if (comparacion == 0) {
            System.out.println("Las cadenas son iguales (ignorando mayúsculas y minúsculas)");
        } else if (comparacion < 0) {
            System.out.println("La cadena1 es menor que la cadena2 (ignorando mayúsculas y minúsculas)");
        } else {
            System.out.println("La cadena1 es mayor que la cadena2 (ignorando mayúsculas y minúsculas)");
        }

//        SRTING concat sirve para poder fusionar o pegar (concatenar) cadenas 
        // Definir dos cadenas
        String cad1 = "Hola, ";
        String cad2 = "mundo!";

        // Usar el método concat para unir las cadenas
        String resultadoString = cad1.concat(cad2);

        // Mostrar el resultado
        System.out.println(resultado);

//        STRING contains sirve para verififcar las subcadenas de una cadena
        boolean contieneSubcadena1 = resultadoString.contains("mundo");
        boolean contieneSubcadena2 = resultadoString.contains("Java");

        // Mostrar los resultados
        System.out.println("¿La cadena contiene 'mundo'? " + contieneSubcadena1);
        System.out.println("¿La cadena contiene 'Java'? " + contieneSubcadena2);

//        STRING equalsIgnoreCase compara dos cadenas sin importar las minusculas y mayusculas
        // Definir dos cadenas
        String cadenita1 = "ESTERNOCLEIDOMASTOIDEO";
        String cadenita2 = "EsTeRnOClEiDoMaStOiDeO";

// Usar el método equalsIgnoreCase para comparar las cadenas
        boolean sonIgualesString = cadenita1.equalsIgnoreCase(cadenita2);

        if (sonIgualesString) {
            System.out.println("Las palabras "+cadenita1+" y "+cadenita2+" Son iguales");
        } else {
            System.out.println("Las palabras "+cadenita1+" y "+cadenita2+" No son iguales");
        }

// Mostrar el resultado
//       STRING replace remplaza cadenas y caracteres 
        // Definir una cadena
        String cadenaOriginal = "Hola, mundo! Hola, Java!";

        // Usar el método replace para reemplazar las ocurrencias
        String nuevaCadena = cadenaOriginal.replace("Hola", "Saludos");

        // Mostrar el resultado
        System.out.println("Cadena original: " + cadenaOriginal);
        System.out.println("Cadena modificada: " + nuevaCadena);

//        STRING subString Devuelve una cadena que es una subcadena de esta cadena.
//        La subcadena comienza con el carácter en el índice especificado y se extiende hasta el final de esta cadena.
        // Definir una cadena
        String cadena = "Hola Guapo, mundo!";

        // Obtener una subcadena desde el índice 0 hasta el 4 (exclusivo)
        String subcadena1 = cadena.substring(0, 5);

        // Obtener una subcadena desde el índice 5 hasta el final
        String subcadena2 = cadena.substring(4);

        // Obtener una subcadena desde el índice 6 hasta el final
        String subcadena3 = cadena.substring(10);

        // Mostrar los resultados
        System.out.println("Subcadena 1: " + subcadena1);
        System.out.println("Subcadena 2: " + subcadena2);
        System.out.println("Subcadena 3: " + subcadena3);
    }

}
