package org.blackcode.EstructuraDeDatos.Actividad4.view;

import java.util.Scanner;

public class Actividad4 {

    public static void main(String[] args) {
        Scanner leyer = new Scanner(System.in);
         boolean continuar = true;

        // Pedimos las dimensiones del "Arreglo dinamico" osea que le vamos a pedir que ingrese
        // el tamaño de las filas y columnas de las matrizes
        System.out.print("Ingrese el número de filas de la matriz A: ");
        int filasA = leyer.nextInt();
        System.out.print("Ingrese el número de columnas de la matriz A: ");
        int columnasA = leyer.nextInt();
         System.out.println("El tamaño de la matriz A es: " + filasA + "x" + columnasA);
         
        System.out.print("Ingrese el número de filas de la matriz B: ");
        int filasB = leyer.nextInt();
        System.out.print("Ingrese el número de columnas de la matriz B: ");
        int columnasB = leyer.nextInt();
         System.out.println("El tamaño de la matriz B es: " + filasB + "x" + columnasB);

        // Las matrices solo se pueden multiplicar si las filas y las columnas coinciden
        // Osea se que si las matrices tiene dimensiones de 2x3 y 3x2 o tambien 2x3 y 2x3
        // se puede hacer la multiplicacion de matrices si no es asi el programa no jala
        // por eso le ponemos esa condicion antes de que lo truenen
        if (columnasA != filasB) {
            System.out.println("No se pueden multiplicar estas matrices. Las columnas de A no coinciden con las filas de B"
                    + "\nRecuerda que la regla es que las matrices deben tener las mismas dimensiones");
            return;
        }

        // Pedimos que ingrese las filas osease los numeros que van pa haya -->
        // osea que si pone 1,1,1 estos se van de esta forma pero el programa los va poniendo pa haya 
        //  |     
        //  |   esto puede confundir al usuario 
        //  v
        // por eso le puese que "Ingrese los elementos de la matriz A (los que van asi -->):" 
        // para que no se confunda
        double[][] matrizA = new double[filasA][columnasA];
        System.out.println("Ingrese los elementos de la matriz A (los que van asi -->):");
        for (int i = 0; i < filasA; i++) {
            for (int j = 0; j < columnasA; j++) {
                matrizA[i][j] = leyer.nextDouble();
            }
        }

        // aca ponemos las filas de b tal cual se explico en el comentario de arriba
        double[][] matrizB = new double[filasB][columnasB];
        System.out.println("Ingrese los elementos de la matriz B (los que van asi -->):");
        for (int i = 0; i < filasB; i++) {
            for (int j = 0; j < columnasB; j++) {
                matrizB[i][j] = leyer.nextDouble();
            }
        }

        // le echamos un grito al metodo multiplicarMatrices para que haga lo suyo
        double[][] matrizC = multiplicarMatrices(matrizA, matrizB);

        // imprimimos el "producto de la matriz osea se la matriz C"
        System.out.println("Matriz C (A * B):");
        imprimirMatriz(matrizC);
    }


// Aca esta el metodo chido para multiplicar el cual nos va a devolver un arreglo bidimencional
// de tipo double, que tiene como parametros dos arreglos al igual que el devuelto es bidimencional
// estos arreglos reprecentan la matrizA y la matriB    
    
    public static double[][] multiplicarMatrices(double[][] matrizA, double[][] matrizB) {
//  aca agarramos el numero de filas que se le pidio al usuario en la matrizA
        int filasA = matrizA.length;
//  aca se pide las columnas de las matrices A y B 
        int columnasA = matrizA[0].length;
        int columnasB = matrizB[0].length;
// Creamos el arreglo que representa a nuestra mastrizC que es nuestro producto
// la cual tiene las filas de la matriizA y las columnas de la matrizB las cuales
// se usan para multiplicar las matrices
        double[][] matrizC = new double[filasA][columnasB];
// en este for lo que hacemos es recorrer las filas de la matrizA y las columnas de la matrizB

        for (int i = 0; i < filasA; i++) {
            for (int j = 0; j < columnasB; j++) {
// este wey ("k") lo que va hacer es recorrer las columnas de matrizA y multiplicar lo
// que esta en la fila de la matrizA con la columna de la matrizB.
                for (int k = 0; k < columnasA; k++) {
//  aca vamos a multiplicar de la siguiente forma
// en algebra es lo mismo
// matrIz A [i0][i1][i2] matriz B [j0][j1][j2]
//          [i3][i4][i5]          [j3][j4][j5]    
//          [i6] i7][18]          [j6][j7][j8]  

// Multiplicación de Matrices:
// K[0][0] = (i0 * j0) + (i1 * j2) + (i2 * j6)=k0,0
// K[0][1] = (i0 * j1) + (i1 * j4) + (i2 * j7)=k3,0
// K[1][0] = (i0 * j2) + (i1 * j5) + (i2 * j8)=k6,0

// matriz C [k0,0][k1,0][k2,0] 
//          [k3,0][k4,1][k5,2]             
//          [k6,0][k7,1][k8,2]
                    matrizC[i][j] += matrizA[i][k] * matrizB[k][j];
                }
            }
        }

        return matrizC;
    }
// Solo es para imprimir la tabla
    public static void imprimirMatriz(double[][] matriz) {
        int filas = matriz.length;
        int columnas = matriz[0].length;
// Cada vuelta del for se le pone los valoores correspondientes a i y j y con "\t" es para
// es para separa los resultados en la Misma fila (es como dar espacio)
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                System.out.print(matriz[i][j] + "\t");
            }
            System.out.println();
        }
    }
    
}
