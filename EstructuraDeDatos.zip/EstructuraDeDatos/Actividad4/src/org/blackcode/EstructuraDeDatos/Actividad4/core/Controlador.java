package org.blackcode.EstructuraDeDatos.Actividad4.core;

import org.blackcode.EstructuraDeDatos.Actividad4.model.Matriz;

public class Controlador {

    private double f =3;
    private double c=4;

    double[][]Matriz = new double[3][4];
    

    public void calcularProductoDeMatrices(double f, double c) {
        
    }
}
