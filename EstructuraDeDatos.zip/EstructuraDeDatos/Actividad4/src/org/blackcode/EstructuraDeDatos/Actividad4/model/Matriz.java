
package org.blackcode.EstructuraDeDatos.Actividad4.model;

public class Matriz {
    private double fila;
    private double columna;

    public Matriz() {
    }

    public Matriz(double fila, double columna) {
        this.fila = fila;
        this.columna = columna;
    }

    public double getFila() {
        return fila;
    }

    public void setFila(double fila) {
        this.fila = fila;
    }

    public double getColumna() {
        return columna;
    }

    public void setColumna(double columna) {
        this.columna = columna;
    }

    @Override
    public String toString() {
        return "Matriz{" + "fila=" + fila + ", columna=" + columna + '}';
    }
    
}
