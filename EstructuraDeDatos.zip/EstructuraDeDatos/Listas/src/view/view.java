/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package view;

import Lista.Lista;
import java.util.Scanner;

/**
 *
 * @author angel
 */
public class view {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Lista lista = new Lista();
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("Menú de Operaciones con Listas Simples:");
            System.out.println("1. Insertar al inicio");
            System.out.println("2. Insertar al final");
            System.out.println("3. Insertar por valor (referencia)");
            System.out.println("4. Insertar por posición");
            System.out.println("5. Buscar por valor (referencia)");
            System.out.println("6. Buscar posición");
            System.out.println("7. Editar por valor (referencia)");
            System.out.println("8. Editar por posición");
            System.out.println("9. Eliminar por valor (referencia)");
            System.out.println("10. Eliminar por posición");
            System.out.println("11. Mostrar la lista");
            System.out.println("12. Eliminar la lista");
            System.out.println("13. Salir");
            System.out.print("Selecciona una opción: ");

            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el valor a insertar al inicio: ");
                    int valorInicio = scanner.nextInt();
                    lista.agregarAlInicio(valorInicio);
                    break;
                case 2:
                    System.out.print("Ingrese el valor a insertar al final: ");
                    int valorFinal = scanner.nextInt();
                    lista.agregarAlFinal(valorFinal);
                    break;
                case 3:
                    System.out.print("Ingrese el valor de referencia: ");
                    int valorReferencia = scanner.nextInt();
                    System.out.print("Ingrese el valor a insertar: ");
                    int valorNuevo = scanner.nextInt();
                    lista.insertarPorReferencia(valorReferencia, valorNuevo);
                    break;
                case 4:
                    System.out.print("Ingrese la posición: ");
                    int posicion = scanner.nextInt();
                    System.out.print("Ingrese el valor a insertar: ");
                    int valorPosicion = scanner.nextInt();
                    lista.insertarPorPosicion(posicion, valorPosicion);
                    break;
                case 5:
                    System.out.print("Ingrese el valor a buscar: ");
                    int valorBuscar = scanner.nextInt();
                    boolean encontrado = lista.buscar(valorBuscar);
                    if (encontrado) {
                        System.out.println("El valor " + valorBuscar + " se encuentra en la lista.");
                    } else {
                        System.out.println("El valor " + valorBuscar + " no se encuentra en la lista.");
                    }
                    break;
                case 6:
                    System.out.print("Ingrese el valor a buscar: ");
                    int valorBusqueda = scanner.nextInt();
                    try {
                        int posicionEncontrada = lista.getPosicion(valorBusqueda);
                        System.out.println("El valor " + valorBusqueda + " se encuentra en la posición " + posicionEncontrada);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 7:
                    System.out.print("Ingrese el valor a editar: ");
                    int valorEditar = scanner.nextInt();
                    System.out.print("Ingrese el nuevo valor: ");
                    int nuevoValor = scanner.nextInt();
                    lista.editarPorReferencia(valorEditar, nuevoValor);
                    break;
                case 8:
                    System.out.print("Ingrese la posición a editar: ");
                    int posEditar = scanner.nextInt();
                    System.out.print("Ingrese el nuevo valor: ");
                    int valorEditarPos = scanner.nextInt();
                    lista.editarPorPosicion(posEditar, valorEditarPos);
                    break;
                case 9:
                    System.out.print("Ingrese el valor a eliminar: ");
                    int valorEliminar = scanner.nextInt();
                    lista.removerPorRferencia(valorEliminar);
                    break;
                case 10:
                    System.out.print("Ingrese la posición a eliminar: ");
                    int posEliminar = scanner.nextInt();
                    lista.removerPorPosicion(posEliminar);
                    break;
                case 11:
                    System.out.println("Contenido de la lista:");
                    lista.listar();
                    break;
                case 12:
                    lista.eliminar();
                    System.out.println("La lista ha sido eliminada.");
                    break;
                case 13:
                    System.out.println("Saliendo del programa.");
                    break;
                default:
                    System.out.println("Opción no válida. Por favor, seleccione una opción válida.");
            }

        } while (opcion != 13);

        scanner.close();
    }
    
}
