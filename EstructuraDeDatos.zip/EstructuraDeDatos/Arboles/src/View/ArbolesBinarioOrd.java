package View;

import modelo.NodoArbol;

/**
 *
 * @author angel
 */
public class ArbolesBinarioOrd {

    public static void main(String[] args) {
        NodoArbol raiz = new NodoArbol(0);
        raiz.agregar(2);
        raiz.agregar(5);
        raiz.agregar(4);
        raiz.agregar(3);
        raiz.agregar(1);
        System.out.println(raiz.existe(1, raiz));
        System.out.println("Mostrar con metodo In-Order");
        raiz.InOrder();
        System.out.println("Mostra con el metodo Pos-Order");
        raiz.PosOrder();
        System.out.println("Mostrar con metodo Pre-Order");
        raiz.PreOrder();
    }
}
