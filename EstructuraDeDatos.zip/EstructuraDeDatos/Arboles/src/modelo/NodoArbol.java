package modelo;

/**
 *
 * @author angel
 */
public class NodoArbol {

    private Integer dato;
    private NodoArbol izquierda;
    private NodoArbol derecha;

    public NodoArbol(Integer dato) {
        this.dato = dato;
    }

    public NodoArbol() {
    }

    public Integer getDato() {
        return dato;
    }

    public void setDato(Integer dato) {
        this.dato = dato;
    }

    public NodoArbol getIzquierda() {
        return izquierda;
    }

    public void setIzquierda(NodoArbol izquierda) {
        this.izquierda = izquierda;
    }

    public NodoArbol getDerecha() {
        return derecha;
    }

    public void setDerecha(NodoArbol derecha) {
        this.derecha = derecha;
    }
//METODO PARA AGREGAR UN DATO DENTRO DEL ARBOL

    public void agregar(Integer dato) {
        if (dato < this.dato) {
            if (izquierda != null) {
                izquierda.agregar(dato);
            } else {
                izquierda = new NodoArbol(dato);
            }
        } else {
            if (derecha != null) {
                derecha.agregar(dato);
            } else {
                derecha = new NodoArbol(dato);
            }
        }
    }
//METODO PARA IMPRIMIR EN "InOrder()"

    public void InOrder() {
        if (izquierda != null) {
            izquierda.InOrder();
        }
        System.out.println(dato);
        if (derecha != null) {
            derecha.InOrder();
        }
    }
//METODO PARA IMPRIMIR  EN "PreOrder"

    public void PreOrder() {
        System.out.println(dato);
        if (izquierda != null) {
            izquierda.PreOrder();
        }
        if (derecha != null) {
            derecha.PreOrder();
        }
    }
//METODO PAR AIMPRIMIR EN "PosOrder"

    public void PosOrder() {

        if (izquierda != null) {
            izquierda.PreOrder();
        }
        if (derecha != null) {
            derecha.PreOrder();
        }
        System.out.println(dato);
    }
//METODO PARA ISABER SI ESXISTE "existe()"

    public String existe(int valor, NodoArbol raiz) {
        NodoArbol reco = raiz;
        while (reco != null) {
            if (valor == reco.dato) {
                return "si existe";
            }else if(valor >reco.dato){
                reco=reco.derecha;
            }else{
                reco = reco.izquierda;
            }
        }
        return "no existe";
    }
}
